local e=require("nixio.fs")
local o=require("luci.util")
local t="/etc/config/dhcp"
if not e.access(t)then
m=SimpleForm("error",nil,translate("Input file not found, please check your configuration."))
m.reset=false
m.submit=false
return m
end
m=SimpleForm("input",nil)
m:append(Template("dnscrypt-proxy/config_css"))
m.submit=translate("Save")
m.reset=false
s=m:section(SimpleSection,nil,
translate("This form allows you to modify the content of the main Dnsmasq configuration file (/etc/config/dhcp)."))
f=s:option(TextValue,"data")
f.rows=20
f.rmempty=true
function f.cfgvalue()
return e.readfile(t)or""
end
function f.write(i,i,a)
return e.writefile(t,"\n"..o.trim(a:gsub("\r\n","\n")).."\n")
end
function s.handle(e,e,e)
return true
end
return m
