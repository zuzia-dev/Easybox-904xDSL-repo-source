require"luci.util"
local e=require"luci.version"
local e={"parted","mdadm","blkid","smartctl","df","btrfs","lsblk"}
local t={command={}}
for a,e in ipairs(e)do
local a=luci.sys.exec("/usr/bin/which "..e)
t.command[e]=a:match("^.+"..e)or nil
end
t.command.mount=nixio.fs.access("/usr/bin/mount")and"/usr/bin/mount"or"/bin/mount"
t.command.umount=nixio.fs.access("/usr/bin/umount")and"/usr/bin/umount"or"/bin/umount"
local c=nixio.fs.readfile("/proc/mounts")or""
local h=luci.util.exec(t.command.mount.." 2>/dev/null")or""
local n=nixio.fs.readfile("/proc/swaps")or""
local s=luci.sys.exec(t.command.df.." 2>/dev/null")or""
function byte_format(e)
local a={"B","KB","MB","GB","TB"}
for t=1,5 do
if e>1024 and t<5 then
e=e/1024
else
return string.format("%.2f %s",e,a[t])
end
end
end
local l=function(e)
local o
local a={}
for e,i in ipairs(luci.util.execl(t.command.smartctl.." -H -A -i -n standby -f brief /dev/"..e))do
local e,t
if o==1 then
e,t=i:match"^(.-):%s+(.+)"
elseif o==2 and a.nvme_ver then
e,t=i:match("^(.-):%s+(.+)")
if not a.health then a.health=i:match(".-overall%-health.-: (.+)")end
elseif o==2 then
e,t=i:match("^([0-9 ]+)%s+[^ ]+%s+[POSRCK-]+%s+[0-9-]+%s+[0-9-]+%s+[0-9-]+%s+[0-9-]+%s+([0-9-]+)")
if not a.health then a.health=i:match(".-overall%-health.-: (.+)")end
else
e=i:match"^=== START OF (.*) SECTION ==="
if e and e:match("INFORMATION")then
o=1
elseif e and e:match("SMART DATA")then
o=2
elseif not a.status then
t=i:match"^Device is in (.*) mode"
if t then a.status=t end
end
end
if not e then
if o~=2 then o=0 end
elseif(e=="Power mode is")or
(e=="Power mode was")then
a.status=t:match("(%S+)")
elseif e=="Serial Number"then
a.sn=t
elseif e=="194"or e=="Temperature"then
if t~="-"then
a.temp=(t:match("(%d+)")or"?").."°C"
end
elseif e=="Rotation Rate"then
a.rota_rate=t
elseif e=="SATA Version is"then
a.sata_ver=t
elseif e=="NVMe Version"then
a.nvme_ver=t
end
end
return a
end
local d=function(o,e)
local a={}
local t={}
for e in e:gmatch("(.-)[:;]")do table.insert(t,e)end
for e=1,#o do
a[o[e]]=t[e]or""
end
return a
end
local r=function(a)
if nixio.fs.access("/proc/mdstat")then
for e,o in ipairs(luci.util.execl("grep md /proc/mdstat | sed 's/[][]//g'"))do
local e,t
e,t=o:match("(md.-):(.+)")
if t:match(a)then
return"Raid Member: "..e
end
end
end
return nil
end
local h=function(t)
local e
for t in h:gmatch("/dev/"..t.." on ([^ ]*)")do
e=(e and(e.." ")or"")..t
end
if e then return e end
if n:match("\n/dev/"..t.."%s")then return"swap"end
return r(t)
end
local u=function(e)
if not nixio.fs.access("/dev/"..e)then return false end
local a,t,e=s:match("\n/dev/"..e.."%s+%d+%s+(%d+)%s+(%d+)%s+(%d+)%%%s-")
e=e and(e.."%")or"-"
a=a and(tonumber(a)*1024)or 0
t=t and(tonumber(t)*1024)or 0
return a,t,e
end
local n=function(o)
if not o then return end
local s={partitions={}}
local r={"path","size","type","logic_sec","phy_sec","p_table","model","flags"}
local l={"number","sec_start","sec_end","size","fs","tag_name","flags"}
local e
local i={}
local a
for n in luci.util.execi(t.command.parted.." -s -m /dev/"..o.." unit s print free","r")do
if n:find("^/dev/"..o..":.+")then
a=d(r,n)
a.partitions={}
if a["size"]then
local e=a["size"]:gsub("^(%d+)s$","%1")
local e=tostring(tonumber(e)*tonumber(a["logic_sec"]))
a["size"]=e
end
if a["p_table"]=="msdos"then
a["p_table"]="MBR"
else
a["p_table"]=a["p_table"]:upper()
end
elseif n:find("^%d-:.+")then
e=d(l,n)
if e["size"]then
local t=e["size"]:gsub("^(%d+)s$","%1")
local t=(tonumber(t)*tonumber(a["logic_sec"]))
e["size"]=t
e["size_formated"]=byte_format(t)
end
e["number"]=tonumber(e["number"])or-1
if e["fs"]=="free"then
e["number"]=-1
e["fs"]="Free Space"
e["name"]="-"
elseif o:match("sd")or o:match("sata")or o:match("vd")then
e["name"]=o..e["number"]
elseif o:match("mmcblk")or o:match("md")or o:match("nvme")then
e["name"]=o.."p"..e["number"]
end
if e["number"]>0 and e["fs"]==""and t.command.lsblk then
e["fs"]=luci.util.exec(t.command.lsblk.." /dev/"..o..tostring(e["number"]).." -no fstype"):match("([^%s]+)")or""
end
e["fs"]=e["fs"]==""and"raw"or e["fs"]
e["sec_start"]=e["sec_start"]and e["sec_start"]:sub(1,-2)
e["sec_end"]=e["sec_end"]and e["sec_end"]:sub(1,-2)
e["mount_point"]=e["name"]~="-"and h(e["name"])or"-"
if e["mount_point"]~="-"then
e["used"],e["free"],e["usage"]=u(e["name"])
e["used_formated"]=e["used"]and byte_format(e["used"])or"-"
e["free_formated"]=e["free"]and byte_format(e["free"])or"-"
else
e["used"],e["free"],e["usage"]=0,0,"-"
e["used_formated"]="-"
e["free_formated"]="-"
end
table.insert(i,e)
end
end
if a and a["p_table"]=="MBR"then
for t,e in ipairs(i)do
if a["extended_partition_index"]and e["number"]>4 then
if tonumber(e["sec_end"])<=tonumber(i[a["extended_partition_index"]]["sec_end"])and tonumber(e["sec_start"])>=tonumber(i[a["extended_partition_index"]]["sec_start"])then
e["type"]="logical"
table.insert(i[a["extended_partition_index"]]["logicals"],t)
end
elseif(e["number"]<=4)and(e["number"]>0)then
local o=nixio.fs.readfile("/sys/block/"..o.."/"..e["name"].."/size")
if o then
local o=tonumber(o)*tonumber(a.logic_sec)
if o~=e["size"]then
a["extended_partition_index"]=t
e["type"]="extended"
e["size"]=o
e["fs"]="-"
e["logicals"]={}
else
e["type"]="primary"
end
else
e["type"]="primary"
end
end
end
end
s=a or s
s.partitions=i
return s
end
local d=function(e)
local a={}
local e=e:match("^/dev/md%d+$")
if e then
local t=io.popen(t.command.mdadm.." --detail "..e,"r")
for e in t:lines()do
local e,t=e:match("^%s*(.+) : (.+)")
if e then
a[e]=t
end
end
t:close()
end
return a
end
t.get_mount_points=function()
local e
local e={}
local o={"device","mount_point","fs","mount_options","dump","pass"}
for a in c:gmatch("[^\n]+")do
local t=a:match("^([^%s]+)%s+.+")
if t and t:match("/dev/")then
e[#e+1]={}
local t=0
for a in a:gmatch("[^%s]+")do
t=t+1
e[#e][o[t]]=a
end
end
end
return e
end
t.get_disk_info=function(o,i)
if not o then return end
local e
local a=l(o)
a["p_table"]=r(o..'0')
if a.status~="STANDBY"or i or(a["p_table"]and not a["p_table"]:match("Raid"))or o:match("^md")then
e=n(o)
e["sec_size"]=e["logic_sec"].."/"..e["phy_sec"]
e["size_formated"]=byte_format(tonumber(e["size"]))
if a.status~="ACTIVE"then a=l(o)end
else
e={}
end
for a,t in pairs(a)do
e[a]=t
end
if e.type and e.type:match("md")then
local t=t.list_raid_devices()[e["path"]:match("/dev/(.+)")]
for a,t in pairs(t)do
e[a]=t
end
end
return e
end
t.list_raid_devices=function()
local o=require"nixio.fs"
local i={}
if not o.access("/proc/mdstat")then return i end
local n=io.open("/proc/mdstat","r")
for t in n:lines()do
local e={}
local a,n=t:match("^(md%d+) : (.+)")
if a then
local t={}
for e in string.gmatch(n,"%S+")do
member_path=e:match("^(%S+)%[%d+%]")
if member_path then
e='/dev/'..member_path
end
table.insert(t,e)
end
local n=table.remove(t,1)
local h="-"
if n=="active"then
h=table.remove(t,1)
end
local s=tonumber(o.readfile(string.format("/sys/class/block/%s/size",a)))
local o=tonumber(o.readfile(string.format("/sys/class/block/%s/queue/logical_block_size",a)))
e["path"]="/dev/"..a
e["size"]=s*o
e["size_formated"]=byte_format(s*o)
e["active"]=n:upper()
e["level"]=h
e["members"]=t
e["members_str"]=table.concat(t,", ")
local t=d(e["path"])
e["status"]=t["State"]:upper()
i[a]=e
end
end
n:close()
return i
end
t.list_devices=function()
local a=require"nixio.fs"
local i={}
for e in a.dir("/dev")do
if e:match("^sd[a-z]$")
or e:match("^mmcblk%d+$")
or e:match("^sata[a-z]$")
or e:match("^nvme%d+n%d+$")
or e:match("^vd[a-z]$")
then
table.insert(i,e)
end
end
local o={}
for e,t in pairs(i)do
local e={}
local i="/dev/"..t
local r=tonumber(a.readfile(string.format("/sys/class/block/%s/size",t))or"0")
local n=tonumber(a.readfile(string.format("/sys/class/block/%s/queue/logical_block_size",t))or"0")
local s=a.readfile(string.format("/sys/class/block/%s/device/model",t))
local a={}
for t in nixio.fs.glob("/sys/block/"..t.."/"..t.."*")do
local o=nixio.fs.basename(t)
local i=byte_format(tonumber(nixio.fs.readfile(t.."/size"))*n)
local t=h(o)
if t then e["inuse"]=true end
table.insert(a,{name=o,size_formated=i,inuse=t})
end
e["path"]=i
e["size_formated"]=byte_format(r*n)
e["model"]=s
e["partitions"]=a
e["inuse"]=e["inuse"]or h(t)
local a={}
if luci.sys.exec("which udevadm")~=""then
local t=io.popen("udevadm info --query=property --name="..i)
for e in t:lines()do
local e,t=e:match("(%S+)=(%S+)")
a[e]=t
end
t:close()
e["info"]=a
if a["ID_MODEL"]then e["model"]=a["ID_MODEL"]end
end
o[t]=e
end
return o
end
t.get_format_cmd=function()
local e={
ext2={cmd="mkfs.ext2",option="-F -E lazy_itable_init=1"},
ext3={cmd="mkfs.ext3",option="-F -E lazy_itable_init=1"},
ext4={cmd="mkfs.ext4",option="-F -E lazy_itable_init=1"},
fat32={cmd="mkfs.fat",option="-F 32"},
exfat={cmd="mkfs.exfat",option=""},
hfsplus={cmd="mkhfs",option="-f"},
ntfs={cmd="mkfs.ntfs",option="-f"},
swap={cmd="mkswap",option=""},
btrfs={cmd="mkfs.btrfs",option="-f"}
}
result={}
for a,e in pairs(e)do
local t=luci.sys.exec("/usr/bin/which "..e["cmd"])
if t:match(e["cmd"])then
result[a]={cmd=t:match("^.+"..e["cmd"]),option=e["option"]}
end
end
return result
end
t.find_free_md_device=function()
for t=0,127 do
local e=io.open("/dev/md"..tostring(t),"r")
if e==nil then
return"/dev/md"..tostring(t)
else
io.close(e)
end
end
return nil
end
t.create_raid=function(e,o,a)
local i={}
for t,e in ipairs(a)do
i[e]=e
end
a={}
for t,e in pairs(i)do
table.insert(a,e)
end
if type(e)=="string"then
if e:match("^md%d-%s+")then
e="/dev/"..e:match("^(md%d-)%s+")
elseif e:match("^/dev/md%d-%s+")then
e="/dev/"..e:match("^(/dev/md%d-)%s+")
elseif not e:match("/")then
e="/dev/md/"..e
else
return"ERR: Invalid raid name"
end
else
e=t.find_free_md_device()
if e==nil then return"ERR: Cannot find free md device"end
end
if o=="5"or o=="6"then
if#a<3 then return"ERR: Not enough members"end
end
if o=="10"then
if#a<4 then return"ERR: Not enough members"end
end
if#a<2 then return"ERR: Not enough members"end
local e=t.command.mdadm.." --create "..e.." --run --assume-clean --homehost=any --level="..o.." --raid-devices="..#a.." "..table.concat(a," ")
local e=luci.util.exec(e)
return e
end
t.gen_mdadm_config=function()
if not nixio.fs.access("/etc/config/mdadm")then return end
local e=require"luci.model.uci"
local e=e.cursor()
e:foreach("mdadm","array",function(t)e:delete("mdadm",t[".name"])end)
local a=t.command.mdadm.." -D -s"
for a,t in ipairs(luci.util.execl(a))do
local t,a=t:match("^ARRAY%s-([^%s]+)%s-[^%s]-%s-[^%s]-%s-UUID=([^%s]+)%s-")
if t and a then
local o=e:add("mdadm","array")
e:set("mdadm",o,"device",t)
e:set("mdadm",o,"uuid",a)
end
end
e:commit("mdadm")
luci.util.exec("/etc/init.d/mdadm enable")
end
t.list_btrfs_devices=function()
local e={}
if not t.command.btrfs then return e end
local o,a
for t,o in ipairs(luci.util.execl(t.command.btrfs.." filesystem show -d --raw"))
do
local t,i=o:match("^Label:%s+([^%s]+)%s+uuid:%s+([^%s]+)")
if t and i then
a=i
local o=t:match("^'([^']+)'")
e[a]={label=o or t,uuid=i}
end
local t=o:match("Total devices[%w%s]+used%s+(%d+)$")
if t then
e[a]["used"]=tonumber(t)
e[a]["used_formated"]=byte_format(tonumber(t))
end
local t,o=o:match("devid[%w.%s]+size%s+(%d+)[%w.%s]+path%s+([^%s]+)$")
if t and o then
e[a]["size"]=e[a]["size"]and e[a]["size"]+tonumber(t)or tonumber(t)
e[a]["size_formated"]=byte_format(e[a]["size"])
e[a]["members"]=e[a]["members"]and e[a]["members"]..", "..o or o
end
end
return e
end
t.create_btrfs=function(a,o,e)
if not t.command.btrfs or type(e)~="table"or next(e)==nil then return"ERR no btrfs support or no members"end
local a=a and" -L "..a or""
local e="mkfs.btrfs -f "..a.." -d "..o.." "..table.concat(e," ")
return luci.util.exec(e)
end
t.get_btrfs_info=function(a)
local h={}
if not a or not t.command.btrfs then return h end
local r=t.command.btrfs.." filesystem show --raw "..a
local i,i,o,e,s
for a,t in ipairs(luci.util.execl(r))do
if not o and not e then
e,o=t:match("^Label:%s+([^%s]+)%s+uuid:%s+([^s]+)")
else
local e=t:match("%s+devid.+path%s+([^%s]+)")
if e then
s=s and(s..", "..e)or e
end
end
end
if not e or not o then return h end
local d=e:match("^'([^']+)'")
r=t.command.btrfs.." filesystem usage -b "..a
local e,a,i,n
for o,t in ipairs(luci.util.execl(r))do
if not e then
e=t:match("^%s+Used:%s+(%d+)")
elseif not a then
a=t:match("^%s+Free %(estimated%):%s+(%d+)")
elseif not i then
i=t:match("^Data,%s-(%w+)")
elseif not n then
n=t:match("^Metadata,%s-(%w+)")
end
end
if e and a and i and n then
e=tonumber(e)
a=tonumber(a)
h={
uuid=o,
label=d,
data_raid_level=i,
metadata_raid_lavel=n,
used=e,
free=a,
size=e+a,
size_formated=byte_format(e+a),
used_formated=byte_format(e),
free_formated=byte_format(a),
members=s,
usage=string.format("%.2f",(e/(a+e)*100)).."%"
}
end
return h
end
t.get_btrfs_subv=function(i,r)
local e={}
if not i or not t.command.btrfs then return e end
local o=t.command.btrfs.." subvolume get-default "..i
local a=luci.util.exec(o)
local d=a:match("^ID%s+([^%s]+)")
if not r then
local l,l,r,n,h,a,s
o=t.command.btrfs.." subvolume show "..i
for t,e in ipairs(luci.util.execl(o))do
if not r then
if not n then
n=e:match("^%s-UUID:%s+([^%s]+)")
elseif not h then
h=e:match("^%s+Creation time:%s+(.+)")
elseif not a then
a=e:match("^%s+Subvolume ID:%s+([^%s]+)")
elseif e:match("^%s+(Snapshot%(s%):)")then
r=true
end
else
local e=e:match("^%s+(.+)")
if e then
s=s and(s..", /"..e)or("/"..e)
end
end
end
if n and h and a then
e["0"..a]={id=a,uuid=n,otime=h,snapshots=s,path="/"}
if d==a then
e["0"..a].default_subvolume=1
end
end
end
o=t.command.btrfs.." subvolume list -gcu"..(r and"s "or" ")..i
for a,u in ipairs(luci.util.execl(o))do
local a,n,s,h,o,d,l
if r then
a,n,s,d,l,h,o=u:match("^ID%s+([^%s]+)%s+gen%s+([^%s]+)%s+cgen.-top level%s+([^%s]+)%s+otime%s+([^%s]+)%s+([^%s]+)%s+uuid%s+([^%s]+)%s+path%s+([^%s]+)%s-$")
else
a,n,s,h,o=u:match("^ID%s+([^%s]+)%s+gen%s+([^%s]+)%s+cgen.-top level%s+([^%s]+)%s+uuid%s+([^%s]+)%s+path%s+([^%s]+)%s-$")
end
if a and n and s and h and o then
e[a]={id=a,gen=n,top_level=s,otime=(d and d or"").." "..(l and l or""),uuid=h,path='/'..o}
if not r then
local t=t.command.btrfs.." subvolume show "..i.."/"..o
local o,o,i
for o,t in ipairs(luci.util.execl(t))do
if not i then
local o=t:match("^%s+Creation time:%s+(.+)")
if o then
e[a]["otime"]=o
elseif t:match("^%s+(Snapshot%(s%):)")then
i="true"
end
else
local t=t:match("^%s+(.+)")
e[a]["snapshots"]=e[a]["snapshots"]and(e[a]["snapshots"]..", /"..t)or("/"..t)
end
end
end
end
end
if e[d]then
e[d].default_subvolume=1
end
return e
end
t.format_partition=function(a,e)
local a="/dev/"..a
if not nixio.fs.access(a)then
return 500,"Partition NOT found!"
end
local t=t.get_format_cmd()
if not t[e]then
return 500,"Filesystem NOT support!"
end
local e=t[e].cmd.." "..t[e].option.." "..a
local e=luci.util.exec(e.." 2>&1")
if e and e:lower():match("error+")then
return 500,e
else
return 200,"OK"
end
end
return t
