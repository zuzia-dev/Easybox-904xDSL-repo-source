require"luci.util"
require("luci.tools.webadmin")
local e=require"luci.model.diskman"
local o=arg[1]
if not o then luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman"))end
mount_point="/tmp/.btrfs_tmp"
nixio.fs.mkdirr(mount_point)
luci.util.exec(e.command.umount.." "..mount_point.." >/dev/null 2>&1")
luci.util.exec(e.command.mount.." -t btrfs -o subvol=/ UUID="..o.." "..mount_point)
m=SimpleForm("btrfs",translate("Btrfs"),translate("Manage Btrfs"))
m.template="diskman/cbi/xsimpleform"
m.redirect=luci.dispatcher.build_url("admin/system/diskman")
m.submit=false
m.reset=false
local t=e.get_btrfs_info(mount_point)
local t=m:section(Table,{t},translate("Btrfs Info"))
t:option(DummyValue,"uuid",translate("UUID"))
t:option(DummyValue,"members",translate("Members"))
t:option(DummyValue,"data_raid_level",translate("Data"))
t:option(DummyValue,"metadata_raid_lavel",translate("Metadata"))
t:option(DummyValue,"size_formated",translate("Size"))
t:option(DummyValue,"used_formated",translate("Used"))
t:option(DummyValue,"free_formated",translate("Free Space"))
t:option(DummyValue,"usage",translate("Usage"))
local i=t:option(Value,"label",translate("Label"))
local a=""
i.write=function(t,t,e)
a=e or""
end
local t=t:option(Button,"_update_label")
t.inputtitle=translate("Update")
t.inputstyle="edit"
t.write=function(t,t,t)
local e=e.command.btrfs.." filesystem label "..mount_point.." "..a
local e=luci.util.exec(e)
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman/btrfs/"..o))
end
local a=e.get_btrfs_subv(mount_point)
a["_"]={ID=0}
table_subvolume=m:section(Table,a,translate("SubVolumes"))
table_subvolume:option(DummyValue,"id",translate("ID"))
table_subvolume:option(DummyValue,"top_level",translate("Top Level"))
table_subvolume:option(DummyValue,"uuid",translate("UUID"))
table_subvolume:option(DummyValue,"otime",translate("Otime"))
table_subvolume:option(DummyValue,"snapshots",translate("Snapshots"))
local n=table_subvolume:option(Value,"path",translate("Path"))
n.forcewrite=true
n.render=function(e,t,o)
if a[t].ID==0 then
e.template="cbi/value"
e.placeholder="/my_subvolume"
e.forcewrite=true
Value.render(e,t,o)
else
e.template="cbi/dvalue"
DummyValue.render(e,t,o)
end
end
local i
n.write=function(t,t,e)
i=e
end
local t=table_subvolume:option(Button,"_subv_set_default",translate("Set Default"))
t.forcewrite=true
t.inputstyle="edit"
t.template="diskman/cbi/disabled_button"
t.render=function(e,o,i)
if a[o].default_subvolume then
e.view_disabled=true
e.inputtitle=translate("Set Default")
elseif a[o].ID==0 then
e.template="cbi/dvalue"
else
e.inputtitle=translate("Set Default")
e.view_disabled=false
end
Button.render(e,o,i)
end
t.write=function(t,n,i)
local t
if i==translate("Set Default")then
t=e.command.btrfs.." subvolume set-default "..mount_point..a[n].path
else
t=e.command.btrfs.." subvolume set-default "..mount_point.."/"
end
local e=luci.util.exec(t.." 2>&1")
if e and(e:match("ERR")or e:match("not enough arguments"))then
m.errmessage=e
else
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman/btrfs/"..o))
end
end
local t=table_subvolume:option(Button,"_subv_remove")
t.template="diskman/cbi/disabled_button"
t.forcewrite=true
t.render=function(o,e,i)
if a[e].ID==0 then
t.inputtitle=translate("Create")
t.inputstyle="add"
o.view_disabled=false
elseif a[e].path=="/"or a[e].default_subvolume then
t.inputtitle=translate("Delete")
t.inputstyle="remove"
o.view_disabled=true
else
t.inputtitle=translate("Delete")
t.inputstyle="remove"
o.view_disabled=false
end
Button.render(o,e,i)
end
t.write=function(t,s,n)
local t
if n==translate("Delete")then
t=e.command.btrfs.." subvolume delete "..mount_point..a[s].path
elseif n==translate("Create")then
if i and i:match("^/")then
t=e.command.btrfs.." subvolume create "..mount_point..i
else
m.errmessage=translate("Please input Subvolume Path, Subvolume must start with '/'")
return
end
end
local e=luci.util.exec(t.." 2>&1")
if e and(e:match("ERR")or e:match("not enough arguments"))then
m.errmessage=luci.util.pcdata(e)
else
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman/btrfs/"..o))
end
end
local n=m:section(SimpleSection,translate("New Snapshot"))
local i,a,s
local t=n:option(Value,"_source",translate("Source Path"),translate("The source path for create the snapshot"))
t.placeholder="/data"
t.forcewrite=true
t.write=function(t,t,e)
i=e
end
local t=n:option(Flag,"_readonly",translate("Readonly"),translate("The path where you want to store the snapshot"))
t.forcewrite=true
t.rmempty=false
t.disabled=0
t.enabled=1
t.default=1
t.write=function(t,t,e)
s=e
end
local t=n:option(Value,"_dest",translate("Destination Path (optional)"))
t.forcewrite=true
t.placeholder="/.snapshot/202002051538"
t.write=function(t,t,e)
a=e
end
local t=n:option(Button,"_snp_create")
t.title=" "
t.inputtitle=translate("New Snapshot")
t.inputstyle="add"
t.write=function(t,t,t)
if i and i:match("^/")then
if not a then a="/.snapshot"..i.."/"..os.date("%Y%m%d%H%M%S")end
nixio.fs.mkdirr(mount_point..a:match("(.-)[^/]+$"))
local e=e.command.btrfs.." subvolume snapshot"..(s==1 and" -r "or" ")..mount_point..i.." "..mount_point..a
local e=luci.util.exec(e.." 2>&1")
if e and(e:match("ERR")or e:match("not enough arguments"))then
m.errmessage=luci.util.pcdata(e)
else
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman/btrfs/"..o))
end
else
m.errmessage=translate("Please input Source Path of snapshot, Source Path must start with '/'")
end
end
return m
