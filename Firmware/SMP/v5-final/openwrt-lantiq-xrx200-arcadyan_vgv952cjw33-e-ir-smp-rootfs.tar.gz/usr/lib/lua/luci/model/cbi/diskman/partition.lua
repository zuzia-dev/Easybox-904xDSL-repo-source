require"luci.util"
require("luci.tools.webadmin")
local o=require"luci.model.diskman"
local a=arg[1]
if not a then
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman"))
elseif not nixio.fs.access("/dev/"..a)then
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman"))
end
m=SimpleForm("partition",translate("Partition Management"),translate("Partition Disk over LuCI."))
m.template="diskman/cbi/xsimpleform"
m.redirect=luci.dispatcher.build_url("admin/system/diskman")
m:append(Template("diskman/partition_info"))
m.submit=false
m.reset=false
local e=o.get_disk_info(a,true)
local h=o.get_format_cmd()
s=m:section(Table,{e},translate("Device Info"))
s:option(DummyValue,"path",translate("Path"))
s:option(DummyValue,"model",translate("Model"))
s:option(DummyValue,"sn",translate("Serial Number"))
s:option(DummyValue,"size_formated",translate("Size"))
s:option(DummyValue,"sec_size",translate("Sector Size"))
local t=s:option(ListValue,"p_table",translate("Partition Table"))
t.render=function(t,o,a)
if not e.p_table:match("Raid")and(#e.partitions==0 or(#e.partitions==1 and e.partitions[1].number==-1)or(e.p_table:match("LOOP")and not e.partitions[1].inuse))then
t:value(e.p_table,e.p_table)
t:value("GPT","GPT")
t:value("MBR","MBR")
t.default=e.p_table
ListValue.render(t,o,a)
else
t.template="cbi/dvalue"
DummyValue.render(t,o,a)
end
end
if e.type:match("md")then
s:option(DummyValue,"level",translate("Level"))
s:option(DummyValue,"members_str",translate("Members"))
else
s:option(DummyValue,"temp",translate("Temp"))
s:option(DummyValue,"sata_ver",translate("SATA Version"))
s:option(DummyValue,"rota_rate",translate("Rotation Rate"))
end
s:option(DummyValue,"status",translate("Status"))
local t=s:option(Button,"health",translate("Health"))
t.render=function(t,a,o)
if e.health then
t.inputtitle=e.health
if e.health=="PASSED"then
t.inputstyle="add"
else
t.inputstyle="remove"
end
Button.render(t,a,o)
else
t.template="cbi/dvalue"
DummyValue.render(t,a,o)
end
end
local t=s:option(Button,"_eject")
t.template="diskman/cbi/disabled_button"
t.inputstyle="remove"
t.render=function(a,o,i)
for t,e in ipairs(e.partitions)do
if e.mount_point~="-"then
a.view_disabled=true
break
end
end
if e.p_table:match("Raid")then
a.view_disabled=true
end
if e.type:match("md")then
t.inputtitle=translate("Remove")
else
t.inputtitle=translate("Eject")
end
Button.render(a,o,i)
end
t.forcewrite=true
t.write=function(t,t,t)
for t,e in ipairs(e.partitions)do
if e.mount_point~="-"then
m.errmessage=e.name..translate("is in use! please unmount it first!")
return
end
end
if e.type:match("md")then
luci.util.exec(o.command.mdadm.." --stop /dev/"..a)
luci.util.exec(o.command.mdadm.." --remove /dev/"..a)
for t,e in ipairs(e.members)do
luci.util.exec(o.command.mdadm.." --zero-superblock "..e)
end
o.gen_mdadm_config()
else
luci.util.exec("echo 1 > /sys/block/"..a.."/device/delete")
end
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman"))
end
if not e.p_table:match("Raid")then
s_partition_table=m:section(Table,e.partitions,translate("Partitions Info"),translate("Default 2048 sector alignment, support +size{b,k,m,g,t} in End Sector"))
s_partition_table:option(DummyValue,"name",translate("Name"))
local n=s_partition_table:option(Value,"sec_start",translate("Start Sector"))
n.render=function(a,t,o)
if e.partitions[t].number==-1 and e.partitions[t].size>1*1024*1024 then
a.template="cbi/value"
Value.render(a,t,o)
else
a.template="cbi/dvalue"
DummyValue.render(a,t,o)
end
end
local i=s_partition_table:option(Value,"sec_end",translate("End Sector"))
i.render=function(t,a,o)
if e.partitions[a].number==-1 and e.partitions[a].size>1*1024*1024 then
t.template="cbi/value"
Value.render(t,a,o)
else
t.template="cbi/dvalue"
DummyValue.render(t,a,o)
end
end
n.forcewrite=true
n.write=function(o,a,t)
e.partitions[a]._sec_start=t
end
i.forcewrite=true
i.write=function(o,a,t)
e.partitions[a]._sec_end=t
end
s_partition_table:option(DummyValue,"size_formated",translate("Size"))
if e.p_table=="MBR"then
s_partition_table:option(DummyValue,"type",translate("Type"))
end
s_partition_table:option(DummyValue,"used_formated",translate("Used"))
s_partition_table:option(DummyValue,"free_formated",translate("Free Space"))
s_partition_table:option(DummyValue,"usage",translate("Usage"))
local t=s_partition_table:option(DummyValue,"mount_point",translate("Mount Point"))
t.rawhtml=true
t.render=function(o,a,i)
local e=""
local t
for t in o["section"]["data"][a]["mount_point"]:gmatch("[^%s]+")do
if t=='-'then
e=t
break
end
for t in t:gmatch('[^/]+')do
if#t>12 then
e=e.."/"..t:sub(1,7)..".."..t:sub(-4)
else
e=e.."/"..t
end
end
e='<span title="'..t..'" >'..e..'</span>'.."<br/>"
end
o["section"]["data"][a]["mount_point"]=e
DummyValue.render(o,a,i)
end
local t=s_partition_table:option(Value,"fs",translate("File System"))
t.forcewrite=true
t.partitions=e.partitions
for e,a in pairs(h)do
t.format_cmd=t.format_cmd and(t.format_cmd..","..e)or e
end
t.write=function(i,o,a)
e.partitions[o]._fs=a
end
t.render=function(a,t,o)
if e.partitions[t].mount_point=="-"and e.partitions[t].number~=-1 and e.partitions[t].type~="extended"then
a.template="diskman/cbi/format_button"
a.inputstyle="reset"
a.inputtitle=e.partitions[t].fs=="raw"and translate("Format")or e.partitions[t].fs
Button.render(a,t,o)
else
a.template="cbi/dvalue"
DummyValue.render(a,t,o)
end
end
local i=s_partition_table:option(Button,"_action")
i.forcewrite=true
i.template="diskman/cbi/disabled_button"
i.render=function(a,t,o)
if e.partitions[t].mount_point~="-"or(e.partitions[t].type~="extended"and e.partitions[t].number==-1 and e.partitions[t].size<=1*1024*1024)then
a.view_disabled=true
elseif e.partitions[t].type=="extended"and next(e.partitions[t]["logicals"])~=nil then
a.view_disabled=true
else
a.view_disabled=false
end
if e.partitions[t].number~=-1 then
a.inputtitle=translate("Remove")
a.inputstyle="remove"
else
a.inputtitle=translate("New")
a.inputstyle="add"
end
Button.render(a,t,o)
end
i.write=function(t,n,h)
if h==translate("New")then
local t=e.partitions[n]._sec_start and tonumber(e.partitions[n]._sec_start)or tonumber(e.partitions[n].sec_start)
local i=e.partitions[n]._sec_end
if t then
local e=tonumber(e.phy_sec)/tonumber(e.logic_sec)
e=(e<2048)and 2048
if t<2048 then
t="2048".."s"
elseif math.fmod(t,e)~=0 then
t=tostring(t+e-math.fmod(t,e)).."s"
else
t=t.."s"
end
else
m.errmessage=translate("Invalid Start Sector!")
return
end
local h,s=i:match("^+(%d-)([bkmgtsBKMGTS])$")
if tonumber(h)and s then
local e={
B=1,
S=512,
K=1024,
M=1048576,
G=1073741824,
T=1099511627776
}
s=s:upper()
i=tostring(tonumber(h)*e[s]/e["S"]+tonumber(t:sub(1,-2))-1).."s"
elseif tonumber(i)then
i=i.."s"
else
m.errmessage=translate("Invalid End Sector!")
return
end
local s="primary"
if e.p_table=="MBR"and e["extended_partition_index"]then
if tonumber(e.partitions[e["extended_partition_index"]].sec_start)<=tonumber(t:sub(1,-2))and tonumber(e.partitions[e["extended_partition_index"]].sec_end)>=tonumber(i:sub(1,-2))then
s="logical"
if tonumber(t:sub(1,-2))-tonumber(e.partitions[n].sec_start)<2048 then
t=tonumber(t:sub(1,-2))+2048
t=t.."s"
end
end
elseif e.p_table=="GPT"then
local e=' printf "ok\nfix\n" | parted ---pretend-input-tty /dev/'..a..' print'
luci.util.exec(e.." 2>&1")
end
local e=o.command.parted.." -s -a optimal /dev/"..a.." mkpart "..s.." "..t.." "..i
local e=luci.util.exec(e.." 2>&1")
if e and e:lower():match("error+")then
m.errmessage=luci.util.pcdata(e)
else
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman/partition/"..a))
end
elseif h==translate("Remove")then
local e=tostring(e.partitions[n].number)
if(not e)or(e=="")then
m.errmessage=translate("Partition not exists!")
return
end
local e=o.command.parted.." -s /dev/"..a.." rm "..e
local e=luci.util.exec(e.." 2>&1")
if e and e:lower():match("error+")then
m.errmessage=luci.util.pcdata(e)
else
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman/partition/"..a))
end
end
end
end
return m