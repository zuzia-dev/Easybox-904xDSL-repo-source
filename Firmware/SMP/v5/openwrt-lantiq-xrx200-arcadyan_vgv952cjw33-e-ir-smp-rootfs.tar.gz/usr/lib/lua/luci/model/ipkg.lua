local i=require"os"
local d=require"io"
local o=require"nixio.fs"
local a=require"luci.util"
local r=type
local l=pairs
local h=error
local t=table
local s="opkg --force-removal-of-dependent-packages --force-overwrite --nocase"
local u="/etc/opkg.conf"
module"luci.model.ipkg"
local function n(e,...)
local e={s,e}
local n,n
for o,t in l({...})do
e[#e+1]=a.shellquote(t)
end
local e="%s >/tmp/opkg.stdout 2>/tmp/opkg.stderr"%t.concat(e," ")
local t=i.execute(e)
local a=o.readfile("/tmp/opkg.stderr")
local e=o.readfile("/tmp/opkg.stdout")
o.unlink("/tmp/opkg.stderr")
o.unlink("/tmp/opkg.stdout")
return t,e or"",a or""
end
local function l(t)
if r(t)~="function"then
h("OPKG: Invalid rawdata given")
end
local n={}
local e={}
local o=nil
for i in t do
if i:sub(1,1)~=" "then
local a,t=i:match("(.-): ?(.*)%s*")
if a and t then
if a=="Package"then
e={Package=t}
n[t]=e
elseif a=="Status"then
e.Status={}
for t in t:gmatch("([^ ]+)")do
e.Status[t]=true
end
else
e[a]=t
end
o=a
end
else
e[o]=e[o].."\n"..i
end
end
return n
end
local function r(o,e)
local o={s,o}
if e then
o[#o+1]=a.shellquote(e)
end
local e=i.tmpname()
i.execute("%s >%s 2>/dev/null"%{t.concat(o," "),e})
local t=l(d.lines(e))
i.remove(e)
return t
end
function info(e)
return r("info",e)
end
function status(e)
return r("status",e)
end
function install(...)
return n("install",...)
end
function installed(e)
local e=status(e)[e]
return(e and e.Status and e.Status.installed)
end
function remove(...)
return n("remove",...)
end
function update()
return n("update")
end
function upgrade()
return n("upgrade")
end
local function r(e,o,h)
local e={s,e}
if o then
e[#e+1]=a.shellquote(o)
end
local n=d.popen(t.concat(e," "))
if n then
local t,e,a,o
while true do
local i=n:read("*l")
if not i then break end
t,e,a,o=i:match("^(.-) %- (.-) %- (.-) %- (.+)")
if not t then
t,e,a=i:match("^(.-) %- (.-) %- (.+)")
o=""
end
if t and e then
if#e>26 then
e=e:sub(1,21)..".."..e:sub(-3,-1)
end
h(t,e,a,o)
end
t=nil
e=nil
a=nil
o=nil
end
n:close()
end
end
function list_all(t,e)
r("list --size",t,e)
end
function list_installed(t,e)
r("list_installed --size",t,e)
end
function find(t,e)
r("find --size",t,e)
end
function overlay_root()
local t="/"
local a=d.open(u,"r")
if a then
local e
repeat
e=a:read("*l")
if e and e:match("^%s*option%s+overlay_root%s+")then
t=e:match("^%s*option%s+overlay_root%s+(%S+)")
local e=o.stat(t)
if not e or e.type~="dir"then
t="/"
end
break
end
until not e
a:close()
end
return t
end
function compare_versions(o,e,i)
if not o or not i
or not e or not(#e>0)then
h("Invalid parameters")
return nil
end
if e=="<>"or e=="><"or e=="!="or e=="~="then e="~="
elseif e=="<="or e=="<"or e=="=<"then e="<="
elseif e==">="or e==">"or e=="=>"then e=">="
elseif e=="="or e=="=="then e="=="
elseif e=="<<"then e="<"
elseif e==">>"then e=">"
else
h("Invalid compare string")
return nil
end
local o=a.split(o,"[%.%-]",nil,true)
local a=a.split(i,"[%.%-]",nil,true)
local i=t.getn(o)
if(t.getn(o)<t.getn(a))then
i=t.getn(a)
end
for i=1,i,1 do
local t=o[i]or""
local a=a[i]or""
if e=="~="and(t~=a)then return true end
if(e=="<"or e=="<=")and(t<a)then return true end
if(e==">"or e==">=")and(t>a)then return true end
if(t~=a)then return false end
end
return not(e=="<"or e==">")
end
