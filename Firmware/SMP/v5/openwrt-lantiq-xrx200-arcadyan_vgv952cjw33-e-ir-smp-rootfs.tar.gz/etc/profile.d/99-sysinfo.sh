/sbin/sysinfo.sh
