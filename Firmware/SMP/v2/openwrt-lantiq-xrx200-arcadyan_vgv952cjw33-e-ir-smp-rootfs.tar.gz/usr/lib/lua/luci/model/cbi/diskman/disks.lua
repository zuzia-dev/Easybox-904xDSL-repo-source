require"luci.util"
require("luci.tools.webadmin")
local e=require"luci.model.diskman"
m=SimpleForm("diskman",translate("DiskMan"),translate("Manage Disks over LuCI."))
m.template="diskman/cbi/xsimpleform"
m:append(Template("diskman/disk_info"))
m.submit=false
m.reset=false
rescan=m:section(SimpleSection)
rescan_button=rescan:option(Button,"_rescan")
rescan_button.inputtitle=translate("Rescan Disks")
rescan_button.template="diskman/cbi/inlinebutton"
rescan_button.inputstyle="add"
rescan_button.forcewrite=true
rescan_button.write=function(t,t,t)
luci.util.exec("echo '- - -' | tee /sys/class/scsi_host/host*/scan > /dev/null")
if e.command.mdadm then
luci.util.exec(e.command.mdadm.." --assemble --scan")
end
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman"))
end
local i=e.list_devices()
d=m:section(Table,i,translate("Disks"))
d.config="disk"
d:option(DummyValue,"path",translate("Path"))
d:option(DummyValue,"model",translate("Model"))
d:option(DummyValue,"sn",translate("Serial Number"))
d:option(DummyValue,"size_formated",translate("Size"))
d:option(DummyValue,"temp",translate("Temp"))
d:option(DummyValue,"p_table",translate("Partition Table"))
d:option(DummyValue,"sata_ver",translate("SATA Version"))
d:option(DummyValue,"health_status",translate("Health").."<br/>"..translate("Status"))
local t=d:option(Button,"_eject")
t.template="diskman/cbi/disabled_button"
t.inputstyle="remove"
t.inputtitle=translate("Eject")
t.forcewrite=true
t.write=function(a,t,a)
local a=t
local t=e.get_disk_info(a,true)
if t.p_table:match("Raid")then
m.errmessage=translate("Unsupported raid reject!")
return
end
for t,e in ipairs(t.partitions)do
if e.mount_point~="-"then
m.errmessage=e.name..translate("is in use! please unmount it first!")
return
end
end
if t.type:match("md")then
luci.util.exec(e.command.mdadm.." --stop /dev/"..a)
luci.util.exec(e.command.mdadm.." --remove /dev/"..a)
for a,t in ipairs(t.members)do
luci.util.exec(e.command.mdadm.." --zero-superblock "..t)
end
e.gen_mdadm_config()
else
luci.util.exec("echo 1 > /sys/block/"..a.."/device/delete")
end
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman"))
end
d.extedit=luci.dispatcher.build_url("admin/system/diskman/partition/%s")
if e.command.mdadm then
local e=e.list_raid_devices()
if next(e)~=nil then
local e=m:section(Table,e,translate("RAID Devices"))
e.config="_raid"
e:option(DummyValue,"path",translate("Path"))
e:option(DummyValue,"level",translate("RAID mode"))
e:option(DummyValue,"size_formated",translate("Size"))
e:option(DummyValue,"p_table",translate("Partition Table"))
e:option(DummyValue,"status",translate("Status"))
e:option(DummyValue,"members_str",translate("Members"))
e:option(DummyValue,"active",translate("Active"))
e.extedit=luci.dispatcher.build_url("admin/system/diskman/partition/%s")
end
end
if e.command.btrfs then
btrfs_devices=e.list_btrfs_devices()
if next(btrfs_devices)~=nil then
local e=m:section(Table,btrfs_devices,translate("Btrfs"))
e:option(DummyValue,"uuid",translate("UUID"))
e:option(DummyValue,"label",translate("Label"))
e:option(DummyValue,"members",translate("Members"))
e:option(DummyValue,"used_formated",translate("Usage"))
e.extedit=luci.dispatcher.build_url("admin/system/diskman/btrfs/%s")
end
end
local t=e.get_mount_points()
local a={}
table.insert(t,{device=0})
local o=m:section(Table,t,translate("Mount Point"))
local n=o:option(Value,"device",translate("Device"))
n.render=function(e,a,o)
if t[a].device==0 then
e.template="cbi/value"
e.forcewrite=true
for a,t in pairs(i)do
for a,t in ipairs(t.partitions)do
e:value("/dev/"..t.name,"/dev/"..t.name.." "..t.size_formated)
end
end
Value.render(e,a,o)
else
e.template="cbi/dvalue"
DummyValue.render(e,a,o)
end
end
n.write=function(t,t,e)
a.device=e and e:gsub("%s+","")or""
end
local n=o:option(Value,"fs",translate("File System"))
n.render=function(e,a,o)
if t[a].device==0 then
e.template="cbi/value"
e:value("auto","auto")
e.default="auto"
e.forcewrite=true
Value.render(e,a,o)
else
e.template="cbi/dvalue"
DummyValue.render(e,a,o)
end
end
n.write=function(t,t,e)
a.fs=e and e:gsub("%s+","")or""
end
local n=o:option(Value,"mount_options",translate("Mount Options"))
n.render=function(a,e,i)
if t[e].device==0 then
a.template="cbi/value"
a.placeholder="rw,noauto"
a.forcewrite=true
Value.render(a,e,i)
else
a.template="cbi/dvalue"
local n=t[e].mount_options
t[e].mount_options=nil
local o=0
for i in n:gmatch("([^,]+)")do
t[e].mount_options=t[e].mount_options and(t[e].mount_options..",")or""
if o>20 then
t[e].mount_options=t[e].mount_options.." <br>"
o=0
end
t[e].mount_options=t[e].mount_options..i
o=o+#i
end
a.rawhtml=true
DummyValue.render(a,e,i)
end
end
n.write=function(t,t,e)
a.mount_options=e and e:gsub("%s+","")or""
end
local n=o:option(Value,"mount_point",translate("Mount Point"))
n.render=function(e,a,o)
if t[a].device==0 then
e.template="cbi/value"
e.placeholder="/media/diskX"
e.forcewrite=true
Value.render(e,a,o)
else
e.template="cbi/dvalue"
local t=""
local i
for a in e["section"]["data"][a]["mount_point"]:gmatch('[^/]+')do
if#a>12 then
t=t.."/"..a:sub(1,7)..".."..a:sub(-4)
else
t=t.."/"..a
end
end
e["section"]["data"][a]["mount_point"]='<span title="'..e["section"]["data"][a]["mount_point"]..'" >'..t..'</span>'
e.rawhtml=true
DummyValue.render(e,a,o)
end
end
n.write=function(t,t,e)
a.mount_point=e
end
local o=o:option(Button,"_mount",translate("Mount"))
o.forcewrite=true
o.render=function(e,a,i)
if t[a].device==0 then
e.inputtitle=translate("Mount")
o.inputstyle="add"
else
e.inputtitle=translate("Umount")
o.inputstyle="remove"
end
Button.render(e,a,i)
end
o.write=function(o,n,i)
local o
if i==translate("Mount")then
if not a.mount_point or not a.device then return end
luci.util.exec("mkdir -p "..a.mount_point)
o=luci.util.exec(e.command.mount.." "..a.device..(a.fs and(" -t "..a.fs)or"")..(a.mount_options and(" -o "..a.mount_options.." ")or" ")..a.mount_point.." 2>&1")
elseif i==translate("Umount")then
o=luci.util.exec(e.command.umount.." "..t[n].mount_point.." 2>&1")
end
if o:match("^mount:")or o:match("^umount:")then
m.errmessage=luci.util.pcdata(o)
else
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman"))
end
end
if e.command.mdadm or e.command.btrfs then
local t=m:section(TypedSection,"_creation")
t.cfgsections=function()
return{translate("Creation")}
end
t:tab("raid",translate("RAID"),translate("RAID Creation"))
t:tab("btrfs",translate("Btrfs"),translate("Multiple Devices Btrfs Creation"))
if e.command.mdadm then
local n,s,h
local a=t:taboption("raid",Value,"_rname",translate("Raid Name"))
a.placeholder=e.find_free_md_device()
a.write=function(t,t,e)
n=e
end
local a=t:taboption("raid",ListValue,"_rlevel",translate("Raid Level"))
local o=luci.util.exec("grep -m1 'Personalities :' /proc/mdstat")
if o:match("%[linear%]")then
a:value("linear","Linear")
end
if o:match("%[raid5%]")then
a:value("5","Raid 5")
end
if o:match("%[raid6%]")then
a:value("6","Raid 6")
end
if o:match("%[raid1%]")then
a:value("1","Raid 1")
end
if o:match("%[raid0%]")then
a:value("0","Raid 0")
end
if o:match("%[raid10%]")then
a:value("10","Raid 10")
end
a.write=function(t,t,e)
h=e
end
local a=t:taboption("raid",DynamicList,"_rmember",translate("Raid Member"))
for t,e in pairs(i)do
if not e.inuse and#e.partitions==0 then
a:value(e.path,e.path.." "..e.size_formated)
end
for t,e in ipairs(e.partitions)do
if not e.inuse then
a:value("/dev/"..e.name,"/dev/"..e.name.." "..e.size_formated)
end
end
end
a.write=function(t,t,e)
s=e
end
local t=t:taboption("raid",Button,"_rcreate")
t.render=function(e,a,o)
e.title=" "
e.inputtitle=translate("Create Raid")
e.inputstyle="add"
Button.render(e,a,o)
end
t.write=function(t,t,t)
local t=e.create_raid(n,h,s)
if t and t:match("^ERR")then
m.errmessage=luci.util.pcdata(t)
return
end
e.gen_mdadm_config()
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman"))
end
end
if e.command.btrfs then
local o,n,s
local a=t:taboption("btrfs",Value,"_blabel",translate("Btrfs Label"))
a.write=function(t,t,e)
o=e
end
local a=t:taboption("btrfs",ListValue,"_blevel",translate("Btrfs Raid Level"))
a:value("single","Single")
a:value("raid0","Raid 0")
a:value("raid1","Raid 1")
a:value("raid10","Raid 10")
a.write=function(t,t,e)
s=e
end
local a=t:taboption("btrfs",DynamicList,"_bmember",translate("Btrfs Member"))
for t,e in pairs(i)do
if not e.inuse and#e.partitions==0 then
a:value(e.path,e.path.." "..e.size_formated)
end
for t,e in ipairs(e.partitions)do
if not e.inuse then
a:value("/dev/"..e.name,"/dev/"..e.name.." "..e.size_formated)
end
end
end
a.write=function(t,t,e)
n=e
end
local t=t:taboption("btrfs",Button,"_bcreate")
t.render=function(e,o,a)
e.title=" "
e.inputtitle=translate("Create Btrfs")
e.inputstyle="add"
Button.render(e,o,a)
end
t.write=function(t,t,t)
local e=e.create_btrfs(o,s,n)
if e and e:match("^ERR")then
m.errmessage=luci.util.pcdata(e)
return
end
luci.http.redirect(luci.dispatcher.build_url("admin/system/diskman"))
end
end
end
return m
