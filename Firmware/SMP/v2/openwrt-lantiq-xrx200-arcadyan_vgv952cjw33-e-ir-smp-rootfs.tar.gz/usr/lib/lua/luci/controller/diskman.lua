require"luci.util"
module("luci.controller.diskman",package.seeall)
function index()
local t={"parted","blkid","smartctl"}
local e=true
for a,t in ipairs(t)do
local a=luci.sys.exec("/usr/bin/which "..t)
if not a:match(t)then
e=false
break
end
end
if not e then return end
entry({"admin","system","diskman"},alias("admin","system","diskman","disks"),_("Disk Man"),55)
entry({"admin","system","diskman","disks"},form("diskman/disks"),nil).leaf=true
entry({"admin","system","diskman","partition"},form("diskman/partition"),nil).leaf=true
entry({"admin","system","diskman","btrfs"},form("diskman/btrfs"),nil).leaf=true
entry({"admin","system","diskman","format_partition"},call("format_partition"),nil).leaf=true
entry({"admin","system","diskman","get_disk_info"},call("get_disk_info"),nil).leaf=true
entry({"admin","system","diskman","mk_p_table"},call("mk_p_table"),nil).leaf=true
entry({"admin","system","diskman","smartdetail"},call("smart_detail"),nil).leaf=true
entry({"admin","system","diskman","smartattr"},call("smart_attr"),nil).leaf=true
end
function format_partition()
local e=luci.http.formvalue("partation_name")
local t=luci.http.formvalue("file_system")
if not e then
luci.http.status(500,"Partition NOT found!")
luci.http.write_json("Partition NOT found!")
return
elseif not nixio.fs.access("/dev/"..e)then
luci.http.status(500,"Partition NOT found!")
luci.http.write_json("Partition NOT found!")
return
elseif not t then
luci.http.status(500,"no file system")
luci.http.write_json("no file system")
return
end
local a=require"luci.model.diskman"
code,msg=a.format_partition(e,t)
luci.http.status(code,msg)
luci.http.write_json(msg)
end
function get_disk_info(e)
if not e then
luci.http.status(500,"no device")
luci.http.write_json("no device")
return
elseif not nixio.fs.access("/dev/"..e)then
luci.http.status(500,"no device")
luci.http.write_json("no device")
return
end
local t=require"luci.model.diskman"
local e=t.get_disk_info(e)
luci.http.status(200,"ok")
luci.http.prepare_content("application/json")
luci.http.write_json(e)
end
function mk_p_table()
local e=luci.http.formvalue("p_table")
local t=luci.http.formvalue("dev")
if not t then
luci.http.status(500,"no device")
luci.http.write_json("no device")
return
elseif not nixio.fs.access("/dev/"..t)then
luci.http.status(500,"no device")
luci.http.write_json("no device")
return
end
local a=require"luci.model.diskman"
if e=="GPT"or e=="MBR"then
e=e=="MBR"and"msdos"or"gpt"
local e=luci.sys.call(a.command.parted.." -s /dev/"..t.." mktable "..e)
if e==0 then
luci.http.status(200,"ok")
else
luci.http.status(500,"command exec error")
end
luci.http.prepare_content("application/json")
luci.http.write_json({code=e})
else
luci.http.status(404,"not support")
luci.http.prepare_content("application/json")
luci.http.write_json({code="1"})
end
end
function smart_detail(e)
luci.template.render("diskman/smart_detail",{dev=e})
end
function smart_attr(a)
local t={}
local e=require"luci.model.diskman"
local a=io.popen(e.command.smartctl.." -H -A -i /dev/%s"%a)
if a then
local e=a:read("*all")
local o
a:close()
if e:match("NVMe Version:")then
for e in string.gmatch(e,'[^\r\n]+')do
if e:match("^(.-):%s+(.+)")then
local e,a=e:match("^(.-):%s+(.+)")
t[#t+1]={
key=e,
value=a
}
end
end
else
for e in string.gmatch(e,'[^\r\n]+')do
if e:match("^.*%d+%s+.+%s+.+%s+.+%s+.+%s+.+%s+.+%s+.+%s+.+%s+.+")then
local e,s,h,n,a,i,o,r,d=e:match("^%s*(%d+)%s+([%a%p]+)%s+(%w+)%s+(%d+)%s+(%d+)%s+(%d+)%s+([%a%p]+)%s+(%a+)%s+[%w%p]+%s+(.+)")
e="%x"%e
if not e:match("^%w%w")then
e="0%s"%e
end
t[#t+1]={
id=e:upper(),
attrbute=s,
flag=h,
value=n,
worst=a,
thresh=i,
type=o,
updated=r,
raw=d
}
end
end
end
end
luci.http.prepare_content("application/json")
luci.http.write_json(t)
end