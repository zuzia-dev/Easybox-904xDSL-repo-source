module("luci.controller.commands",package.seeall)
function index()
entry({"admin","system","commands"},firstchild(),_("Custom Commands"),80).acl_depends={"luci-app-commands"}
entry({"admin","system","commands","dashboard"},template("commands"),_("Dashboard"),1)
entry({"admin","system","commands","config"},cbi("commands"),_("Configure"),2)
entry({"admin","system","commands","run"},call("action_run"),nil,3).leaf=true
entry({"admin","system","commands","download"},call("action_download"),nil,3).leaf=true
entry({"command"},call("action_public"),nil,1).leaf=true
end
local function r(o)
local h={}
local function u(e)
if e==9 or e==10 or e==11 or e==12 or e==13 or e==32 then
return e
end
end
local function d(e)
if e==34 or e==39 or e==96 then
return e
end
end
local function l(e)
if e==92 then
return e
end
end
local function c(e)
if e==36 or e==92 or e==96 then
return e
end
end
local function s(o)
local e={}
local i=256
local s=unpack
local n=string.char
local r=math.min
local t=#o
local a
for a=1,t,i do
e[#e+1]=n(s(o,a,r(a+i-1,t)))
end
h[#h+1]=table.concat(e)
end
local function r(n,t)
local e,i,a
local e={}
for t=n,t do
local t=o:byte(t)
local o=d(t)
local s=l(t)
local n=c(t)
if s then
i=true
elseif i then
if n then e[#e+1]=92 end
e[#e+1]=t
i=false
elseif o and a and o==a then
a=nil
elseif o and not a then
a=o
else
if n then e[#e+1]=92 end
e[#e+1]=t
end
end
s(e)
end
local a,n,e,t
for a=1,#o+1 do
local s=o:byte(a)
local i=d(s)
local o=u(s)or(a>#o)
local s=l(s)
if n then
n=false
elseif s then
n=true
elseif i and t and i==t then
t=nil
elseif i and not t then
e=e or a
t=i
elseif o and not t then
if e then
r(e,a-1)
e=nil
end
else
e=e or a
end
end
if t then
r(e,#o)
end
return h
end
local function i(e,a)
local t=require"luci.model.uci".cursor()
if t:get("luci",e)=="command"then
local t=t:get_all("luci",e)
local e=r(t.command)
local o,o
if t.param=="1"and a then
for a,t in ipairs(r(luci.http.urldecode(a)))do
e[#e+1]=t
end
end
for a,t in ipairs(e)do
if t:match("[^%w%.%-i/|]")then
e[a]='"%s"'%t:gsub('"','\\"')
end
end
return e
end
end
function execute_command(n,...)
local e=require"nixio.fs"
local t=i(...)
if t then
local o=os.tmpname()
local a=os.tmpname()
local s=os.execute(table.concat(t," ").." >%s 2>%s"%{o,a})
local i=e.readfile(o,1024*512)or""
local h=e.readfile(a,1024*512)or""
e.unlink(o)
e.unlink(a)
local e=not not(i:match("[%z\1-\8\14-\31]"))
n({
ok=true,
command=table.concat(t," "),
stdout=not e and i,
stderr=h,
exitcode=s,
binary=e
})
else
n({
ok=false,
code=404,
reason="No such command"
})
end
end
function return_json(e)
if e.ok then
luci.http.prepare_content("application/json")
luci.http.write_json(e)
else
luci.http.status(e.code,e.reason)
end
end
function action_run(...)
execute_command(return_json,...)
end
function return_html(e)
if e.ok then
require("luci.template")
luci.template.render("commands_public",{
exitcode=e.exitcode,
stdout=e.stdout,
stderr=e.stderr
})
else
luci.http.status(e.code,e.reason)
end
end
function action_download(...)
local o=require"nixio.fs"
local e=i(...)
if e then
local a=io.popen(table.concat(e," ").." 2>/dev/null")
if a then
local t=a:read(4096)or""
local i
if t:match("[%z\1-\8\14-\31]")then
luci.http.header("Content-Disposition","attachment; filename=%s"
%o.basename(e[1]):gsub("%W+",".")..".bin")
luci.http.prepare_content("application/octet-stream")
else
luci.http.header("Content-Disposition","attachment; filename=%s"
%o.basename(e[1]):gsub("%W+",".")..".txt")
luci.http.prepare_content("text/plain")
end
while t do
luci.http.write(t)
t=a:read(4096)
end
a:close()
else
luci.http.status(500,"Failed to execute command")
end
else
luci.http.status(404,"No such command")
end
end
function action_public(e,t)
local o=false
if string.sub(e,-1)=="s"then
o=true
e=string.sub(e,1,-2)
end
local a=require"luci.model.uci".cursor()
if e and
a:get("luci",e)=="command"and
a:get("luci",e,"public")=="1"
then
if o then
execute_command(return_html,e,t)
else
action_download(e,t)
end
else
luci.http.status(403,"Access to command denied")
end
end
