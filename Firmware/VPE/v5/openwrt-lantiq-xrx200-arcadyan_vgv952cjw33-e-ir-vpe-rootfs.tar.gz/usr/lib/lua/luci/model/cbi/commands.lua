local t,e
t=Map("luci",translate("Custom Commands"),
translate("This page allows you to configure custom shell commands which can be easily invoked from the web interface."))
e=t:section(TypedSection,"command","")
e.template="cbi/tblsection"
e.anonymous=true
e.addremove=true
e:option(Value,"name",translate("Description"),
translate("A short textual description of the configured command"))
e:option(Value,"command",translate("Command"),
translate("Command line to execute"))
e:option(Flag,"param",translate("Custom arguments"),
translate("Allow the user to provide additional command line arguments"))
e:option(Flag,"public",translate("Public access"),
translate("Allow executing the command and downloading its output without prior authentication"))
return t
