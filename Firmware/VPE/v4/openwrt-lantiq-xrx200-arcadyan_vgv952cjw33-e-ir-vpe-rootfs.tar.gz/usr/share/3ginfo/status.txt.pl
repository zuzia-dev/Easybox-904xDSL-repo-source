Status: {STATUS}
Czas polaczenia: {CONN_TIME}
Przeslano danych: {RX} / {TX}
Operator: {COPS}
Tryb pracy: {MODE}
Sila sygnalu: {CSQ_PER}%
Urzadzenie: {DEVICE}
MCC MNC: {COPS_MCC} {COPS_MNC}
LAC: {LAC} ({LAC_NUM})
CID: {CID} ({CID_NUM})
TAC: {TAC} ({TAC_NUM})
CSQ: {CSQ}
RSSI: {CSQ_RSSI} dBm
RSCP: {RSCP} dBm
Ec/IO: {ECIO} dB
RSRP: {RSRP} dBm
SINR: {SINR} dB
RSRQ: {RSRQ} dB
