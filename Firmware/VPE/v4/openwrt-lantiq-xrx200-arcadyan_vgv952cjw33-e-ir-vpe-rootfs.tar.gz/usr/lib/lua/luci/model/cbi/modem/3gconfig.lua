require("nixio.fs")
local a
local e
local n,i,t
local o=nixio.fs.glob("/dev/tty[A-Z][A-Z]*")
a=Map("3ginfo",translate("Configuration 3ginfo"),
translate("Configuration panel for the 3ginfo application."))
e=a:section(TypedSection,"3ginfo","<p>&nbsp;</p>"..translate(""))
e.anonymous=true
e:option(Value,"network",translate("Network"))
e.rmempty=true
n=e:option(Value,"device",translate("Device"))
if o then
local e
for e in o do
n:value(e,e)
end
end
i=e:option(Value,"pincode",translate("SIM PIN (optional)"))
i.default=""
t=e:option(Value,"language",translate("Language"))
t:value("pl","Polski")
t:value("en","English")
t.default="pl"
return a
