local c=require"io"
local E=require"math"
local p=require"table"
local T=require"debug"
local z=require"luci.debug"
local a=require"string"
local s=require"coroutine"
local e=require"luci.template.parser"
local q=require"luci.jsonc"
local i=require"lucihttp"
local j=require"ubus"
local d=nil
local l,h=getmetatable,setmetatable
local y,x,v,u=rawget,rawset,unpack,select
local o,t,g,b=tostring,type,assert,error
local w,r,A,k=ipairs,pairs,next,loadstring
local m,f,O=require,pcall,xpcall
local e,e=collectgarbage,get_memory_limit
module"luci.util"
l("").__mod=function(i,e)
local n,a
if not e then
return i
elseif t(e)=="table"then
local s,s
for a,i in r(e)do if t(e[a])=="userdata"then e[a]=o(e[a])end end
n,a=f(i.format,i,v(e))
if not n then
b(a,2)
end
return a
else
if t(e)=="userdata"then e=o(e)end
n,a=f(i.format,i,e)
if not n then
b(a,2)
end
return a
end
end
local function n(e,...)
local e=h({},{__index=e})
if e.__init__ then
e:__init__(...)
end
return e
end
function class(e)
return h({},{
__call=n,
__index=e
})
end
function instanceof(e,t)
local e=l(e)
while e and e.__index do
if e.__index==t then
return true
end
e=l(e.__index)
end
return false
end
coxpt=h({},{__mode="kv"})
local n={
__mode="k",
__index=function(e,t)
local e=y(e,coxpt[s.running()]
or s.running()or 0)
return e and e[t]
end,
__newindex=function(e,i,t)
local o=coxpt[s.running()]or s.running()or 0
local a=y(e,o)
if not a then
x(e,o,{[i]=t})
else
a[i]=t
end
end
}
function threadlocal(e)
return h(e or{},n)
end
function perror(e)
return c.stderr:write(o(e).."\n")
end
function dumptable(i,s,e,n)
e=e or 0
n=n or h({},{__mode="k"})
for h,i in r(i)do
perror(a.rep("\t",e)..o(h).."\t"..o(i))
if t(i)=="table"and(not s or e<s)then
if not n[i]then
n[i]=true
dumptable(i,s,e+1,n)
else
perror(a.rep("\t",e).."*** RECURSION ***")
end
end
end
end
function pcdata(e)
local t=m"luci.xml"
perror("luci.util.pcdata() has been replaced by luci.xml.pcdata() - Please update your code.")
return t.pcdata(e)
end
function urlencode(e)
if e~=nil then
local e=o(e)
return i.urlencode(e,i.ENCODE_IF_NEEDED+i.ENCODE_FULL)
or e
end
return nil
end
function urldecode(e,t)
if e~=nil then
local t=t and i.DECODE_PLUS or 0
local e=o(e)
return i.urldecode(e,i.DECODE_IF_NEEDED+t)
or e
end
return nil
end
function striptags(t)
local e=m"luci.xml"
perror("luci.util.striptags() has been replaced by luci.xml.striptags() - Please update your code.")
return e.striptags(t)
end
function shellquote(e)
return a.format("'%s'",a.gsub(e or"","'","'\\''"))
end
function shellsqescape(t)
local e
e,_=a.gsub(t,"'","'\\''")
return e
end
function shellstartsqescape(e)
res,_=a.gsub(e,"^%-","\\-")
return shellsqescape(res)
end
function split(e,i,t,n)
i=i or"\n"
t=t or#e
local a={}
local o=1
if#e==0 then
return{""}
end
if#i==0 then
return nil
end
if t==0 then
return e
end
repeat
local i,n=e:find(i,o,not n)
t=t-1
if i and t<0 then
a[#a+1]=e:sub(o)
else
a[#a+1]=e:sub(o,i and i-1)
end
o=n and n+1 or#e+1
until not i or t<0
return a
end
function trim(e)
return(e:gsub("^%s*(.-)%s*$","%1"))
end
function cmatch(t,a)
local e=0
for t in t:gmatch(a)do e=e+1 end
return e
end
function imatch(e)
if t(e)=="table"then
local t=nil
return function()
t=A(e,t)
return e[t]
end
elseif t(e)=="number"or t(e)=="boolean"then
local t=true
return function()
if t then
t=false
return o(e)
end
end
elseif t(e)=="userdata"or t(e)=="string"then
return o(e):gmatch("%S+")
end
return function()end
end
function parse_units(o)
local e=0
local t={
y=60*60*24*366,
m=60*60*24*31,
w=60*60*24*7,
d=60*60*24,
h=60*60,
min=60,
kb=1024,
mb=1024*1024,
gb=1024*1024*1024,
kib=1000,
mib=1000*1000,
gib=1000*1000*1000
}
for a in o:lower():gmatch("[0-9%.]+[a-zA-Z]*")do
local o=a:gsub("[^0-9%.]+$","")
local a=a:gsub("^[0-9%.]+","")
if t[a]or t[a:sub(1,1)]then
e=e+o*(t[a]or t[a:sub(1,1)])
else
e=e+o
end
end
return e
end
a.split=split
a.trim=trim
a.cmatch=cmatch
a.parse_units=parse_units
function append(e,...)
for o,a in w({...})do
if t(a)=="table"then
for a,t in w(a)do
e[#e+1]=t
end
else
e[#e+1]=a
end
end
return e
end
function combine(...)
return append({},...)
end
function contains(t,e)
for a,t in r(t)do
if e==t then
return a
end
end
return false
end
function update(a,e)
for t,e in r(e)do
a[t]=e
end
end
function keys(t)
local e={}
if t then
for t,a in kspairs(t)do
e[#e+1]=t
end
end
return e
end
function clone(a,o)
local i={}
for a,e in r(a)do
if o and t(e)=="table"then
e=clone(e,o)
end
i[a]=e
end
return h(i,l(a))
end
function _serialize_table(o,a)
g(not a[o],"Recursion detected.")
a[o]=true
local i=""
local n=""
local s=0
for e,n in r(o)do
if t(e)~="number"or e<1 or E.floor(e)~=e or(e-#o)>3 then
e=serialize_data(e,a)
n=serialize_data(n,a)
i=i..(#i>0 and", "or"")..
'['..e..'] = '..n
elseif e>s then
s=e
end
end
for e=1,s do
local e=serialize_data(o[e],a)
n=n..(#n>0 and", "or"")..e
end
return n..(#i>0 and#n>0 and", "or"")..i
end
function serialize_data(e,a)
a=a or h({},{__mode="k"})
if e==nil then
return"nil"
elseif t(e)=="number"then
return e
elseif t(e)=="string"then
return"%q"%e
elseif t(e)=="boolean"then
return e and"true"or"false"
elseif t(e)=="function"then
return"loadstring(%q)"%get_bytecode(e)
elseif t(e)=="table"then
return"{ ".._serialize_table(e,a).." }"
else
return'"[unhandled data type:'..t(e)..']"'
end
end
function restore_data(e)
return k("return "..e)()
end
function get_bytecode(o)
local e
if t(o)=="function"then
e=a.dump(o)
else
e=a.dump(k("return "..serialize_data(o)))
end
return e
end
function strip_bytecode(r)
local t,t,e,i,s,u,l,c=r:byte(5,12)
local t
if e==1 then
t=function(o,a,t)
local e=0
for t=t,1,-1 do
e=e*256+o:byte(a+t-1)
end
return e,a+t
end
else
t=function(o,a,t)
local e=0
for t=1,t,1 do
e=e*256+o:byte(a+t-1)
end
return e,a+t
end
end
local function d(o)
local n,e=t(o,1,s)
local h={a.rep("\0",s)}
local r=e+n
e=e+n+i*2+4
e=e+i+t(o,e,i)*u
n,e=t(o,e,i)
for a=1,n do
local a
a,e=t(o,e,1)
if a==1 then
e=e+1
elseif a==4 then
e=e+s+t(o,e,s)
elseif a==3 then
e=e+l
elseif a==254 or a==9 then
e=e+c
end
end
n,e=t(o,e,i)
h[#h+1]=o:sub(r,e-1)
for t=1,n do
local t,a=d(o:sub(e,-1))
h[#h+1]=t
e=e+a-1
end
e=e+t(o,e,i)*i+i
n,e=t(o,e,i)
for a=1,n do
e=e+t(o,e,s)+s+i*2
end
n,e=t(o,e,i)
for a=1,n do
e=e+t(o,e,s)+s
end
h[#h+1]=a.rep("\0",i*3)
return p.concat(h),e
end
return r:sub(1,12)..d(r:sub(13,-1))
end
function _sortiter(a,o)
local e={}
local t,t
for t,a in r(a)do
e[#e+1]=t
end
local t=0
p.sort(e,o)
return function()
t=t+1
if t<=#e then
return e[t],a[e[t]],t
end
end
end
function spairs(t,e)
return _sortiter(t,e)
end
function kspairs(e)
return _sortiter(e)
end
function vspairs(e)
return _sortiter(e,function(t,a)return e[t]<e[a]end)
end
function bigendian()
return a.byte(a.dump(function()end),7)==0
end
function exec(e)
local e=c.popen(e)
local t=e:read("*a")
e:close()
return t
end
function execi(e)
local e=c.popen(e)
return e and function()
local t=e:read()
if not t then
e:close()
end
return t
end
end
function execl(e)
local a=c.popen(e)
local e=""
local t={}
while true do
e=a:read()
if(e==nil)then break end
t[#t+1]=e
end
a:close()
return t
end
local o={
"INVALID_COMMAND",
"INVALID_ARGUMENT",
"METHOD_NOT_FOUND",
"NOT_FOUND",
"NO_DATA",
"PERMISSION_DENIED",
"TIMEOUT",
"NOT_SUPPORTED",
"UNKNOWN_ERROR",
"CONNECTION_FAILED"
}
local function i(...)
if u('#',...)==2 then
local a,e=u(1,...),u(2,...)
if a==nil and t(e)=="number"then
return nil,e,o[e]
end
end
return...
end
function ubus(e,o,a,n,s)
if not d then
d=j.connect(n,s)
g(d,"Unable to establish ubus connection")
end
if e and o then
if t(a)~="table"then
a={}
end
return i(d:call(e,o,a))
elseif e then
return d:signatures(e)
else
return d:objects()
end
end
function serialize_json(e,a)
local e=q.stringify(e)
if t(a)=="function"then
a(e)
else
return e
end
end
function libpath()
return m"nixio.fs".dirname(z.__file__)
end
function checklib(t,i)
local e=m"nixio.fs"
local o=e.access('/usr/bin/ldd')
local e=e.access(t)
if not o or not e then
return false
end
local e=exec(a.format("/usr/bin/ldd %s",shellquote(t)))
if not e then
return false
end
for t,e in w(split(e))do
if e:find(i)then
return true
end
end
return false
end
local n=h({},{__mode="k"})
local function o(t,e,a,...)
if not a then
return false,t(T.traceback(e,(...)),...)
end
if s.status(e)=='suspended'then
return performResume(t,e,s.yield(...))
else
return true,...
end
end
function performResume(t,e,...)
return o(t,e,s.resume(e,...))
end
local function i(e,...)
return e
end
function coxpcall(e,o,...)
local t=s.running()
if not t then
if o==i then
return f(e,...)
else
if u("#",...)>0 then
local a,t=e,{...}
e=function()return a(v(t))end
end
return O(e,o)
end
else
local i,a=f(s.create,e)
if not i then
local e=function(...)return e(...)end
a=s.create(e)
end
n[a]=t
coxpt[a]=coxpt[t]or t or 0
return performResume(o,a,...)
end
end
function copcall(e,...)
return coxpcall(e,i,...)
end
