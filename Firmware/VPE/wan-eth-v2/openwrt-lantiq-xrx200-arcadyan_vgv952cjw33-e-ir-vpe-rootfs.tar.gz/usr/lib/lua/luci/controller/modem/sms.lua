local e=require"luci.util"
local e=require"nixio.fs"
local e=require"luci.sys"
local e=require"luci.http"
local e=require"luci.dispatcher"
local e=require"luci.http"
local t=require"luci.sys"
local t=require"luci.model.uci".cursor()
module("luci.controller.modem.sms",package.seeall)
function index()
entry({"admin","modem"},firstchild(),"Modem",30).dependent=false
entry({"admin","modem","sms"},alias("admin","modem","sms","readsms"),translate("SMS Messages"),20).acl_depends={"luci-app-sms-tool"}
entry({"admin","modem","sms","readsms"},template("modem/readsms"),translate("Received Messages"),10)
entry({"admin","modem","sms","sendsms"},template("modem/sendsms"),translate("Send Messages"),20)
entry({"admin","modem","sms","ussd"},template("modem/ussd"),translate("USSD Codes"),30)
entry({"admin","modem","sms","atcommands"},template("modem/atcommands"),translate("AT Commands"),40)
entry({"admin","modem","sms","smsconfig"},cbi("modem/smsconfig"),translate("Configuration"),50)
entry({"admin","modem","sms","delete_one"},call("delete_sms",smsindex),nil).leaf=true
entry({"admin","modem","sms","delete_all"},call("delete_all_sms"),nil).leaf=true
entry({"admin","modem","sms","run_ussd"},call("ussd"),nil).leaf=true
entry({"admin","modem","sms","run_at"},call("at"),nil).leaf=true
entry({"admin","modem","sms","run_sms"},call("sms"),nil).leaf=true
entry({"admin","modem","sms","readsim"},call("slots"),nil).leaf=true
entry({"admin","modem","sms","countsms"},call("count_sms"),nil).leaf=true
entry({"admin","modem","sms","user_ussd"},call("userussd"),nil).leaf=true
entry({"admin","modem","sms","user_atc"},call("useratc"),nil).leaf=true
entry({"admin","modem","sms","user_phonebook"},call("userphb"),nil).leaf=true
end
function delete_sms(e)
local t=tostring(t:get("sms_tool","general","readport"))
local e=e
for e in e:gmatch("%d+")do
os.execute("sms_tool -d "..t.." delete "..e.."")
end
end
function delete_all_sms()
local e=tostring(t:get("sms_tool","general","readport"))
os.execute("sms_tool -d "..e.." delete all")
end
function get_ussd()
local e=luci.model.uci.cursor()
if e:get("sms_tool","general","ussd")=="1"then
return" -R"
else
return""
end
end
function get_pdu()
local e=luci.model.uci.cursor()
if e:get("sms_tool","general","pdu")=="1"then
return" -r"
else
return""
end
end
function ussd()
local i=tostring(t:get("sms_tool","general","ussdport"))
local a=get_ussd()
local o=get_pdu()
local t=e.formvalue("code")
if t then
local t=io.popen("sms_tool -d "..i..a..o.." ussd "..t.." 2>&1")
local a=t:read("*a")
t:close()
e.write(tostring(a))
else
e.write_json(e.formvalue())
end
end
function at()
local a=tostring(t:get("sms_tool","general","atport"))
local t=e.formvalue("code")
if t then
local t=io.popen("sms_tool -d "..a.." at "..t:gsub("[$]","\\\$"):gsub("\"","\\\"").." 2>&1")
local a=t:read("*a")
t:close()
e.write(tostring(a))
else
e.write_json(e.formvalue())
end
end
function sms()
local a=tostring(t:get("sms_tool","general","sendport"))
local t=e.formvalue("scode")
nr=(string.sub(t,1,20))
msgall=string.sub(t,21)
msg=string.gsub(msgall,"\n"," ")
if t then
local t=io.popen("sms_tool -d "..a.." send "..nr.." '"..msg.."'")
local a=t:read("*a")
t:close()
e.write(tostring(a))
else
e.write_json(e.formvalue())
end
end
function slots()
local e={}
local a=tostring(t:get("sms_tool","general","readport"))
local i=tostring(t:get("sms_tool","general","smsled"))
local o=tostring(t:get("sms_tool","general","ledtype"))
local n=tostring(t:get("sms_tool","general","lednotify"))
local t=tostring(t:get("sms_tool","general","storage"))
local a=luci.util.exec("sms_tool -s"..t.." -d "..a.." status")
local t=string.sub(a,23,27)
local a=a:match('[^: ]+$')
e["use"]=string.match(t,'%d+')
local t=string.match(t,'%d+')
if n=="1"then
luci.sys.call("echo "..t.." > /etc/config/sms_count")
if o=="S"then
luci.util.exec("/etc/init.d/led restart")
end
if o=="D"then
luci.sys.call("echo 0 > '/sys/class/leds/"..i.."/brightness'")
end
end
e["all"]=string.match(a,'%d+')
luci.http.prepare_content("application/json")
luci.http.write_json(e)
end
function count_sms()
os.execute("sleep 3")
local e=luci.model.uci.cursor()
if e:get("sms_tool","general","lednotify")=="1"then
local a=tostring(t:get("sms_tool","general","readport"))
local e=tostring(t:get("sms_tool","general","storage"))
local e=luci.util.exec("sms_tool -s"..e.." -d "..a.." status")
local e=string.sub(e,23,27)
local e=string.match(e,'%d+')
os.execute("echo "..e.." > /etc/config/sms_count")
end
end
function uussd(t)
local e=nixio.fs.access("/etc/config/ussd.user")and
io.popen("cat /etc/config/ussd.user")
if e then
for a in e:lines()do
local e=a
if e then
t[#t+1]={
usd=e
}
end
end
e:close()
end
end
function userussd()
local e={}
uussd(e)
luci.http.prepare_content("application/json")
luci.http.write_json(e)
end
function uat(t)
local e=nixio.fs.access("/etc/config/atcmds.user")and
io.popen("cat /etc/config/atcmds.user")
if e then
for a in e:lines()do
local e=a
if e then
t[#t+1]={
atu=e
}
end
end
e:close()
end
end
function useratc()
local e={}
uat(e)
luci.http.prepare_content("application/json")
luci.http.write_json(e)
end
function uphb(t)
local e=nixio.fs.access("/etc/config/phonebook.user")and
io.popen("cat /etc/config/phonebook.user")
if e then
for a in e:lines()do
local e=a
if e then
t[#t+1]={
phb=e
}
end
end
e:close()
end
end
function userphb()
local e={}
uphb(e)
luci.http.prepare_content("application/json")
luci.http.write_json(e)
end
