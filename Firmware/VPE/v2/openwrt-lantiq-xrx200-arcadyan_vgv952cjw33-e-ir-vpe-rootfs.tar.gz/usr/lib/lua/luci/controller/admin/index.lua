module("luci.controller.admin.index",package.seeall)
function action_logout()
local e=require"luci.dispatcher"
local a=require"luci.util"
local t=e.context.authsession
if t then
a.ubus("session","destroy",{ubus_rpc_session=t})
luci.http.header("Set-Cookie","sysauth=%s; expires=%s; path=%s"%{
'','Thu, 01 Jan 1970 01:00:00 GMT',e.build_url()
})
end
luci.http.redirect(e.build_url())
end
function action_translations(e)
local a=require"luci.i18n"
local t=require"luci.http"
local o=require"nixio".fs
if e and#e>0 then
e=a.setlanguage(e)
if e then
local e=o.stat("%s/base.%s.lmo"%{a.i18ndir,e})
if e then
t.header("Cache-Control","public, max-age=31536000")
t.header("ETag","%x-%x-%x"%{e["ino"],e["size"],e["mtime"]})
end
end
end
t.prepare_content("application/javascript; charset=utf-8")
t.write("window.TR=")
t.write_json(a.dump())
end
local function t(t,o,e,a)
local t={jsonrpc="2.0",id=t}
if a then
t.error={
code=e,
message=a
}
elseif type(e)=="table"then
t.result=e
else
t.result={e,o}
end
return t
end
local h={
nil,
"array",
"object",
"string",
nil,
"number",
nil,
"boolean",
"double"
}
local function r(e,a,t)
local e,t=luci.util.ubus("session","access",{
ubus_rpc_session=e,
scope="ubus",
object=a,
["function"]=t
})
return(type(e)=="table"and e.access==true)
end
local function s(e)
if type(e)~="table"or type(e.method)~="string"or e.jsonrpc~="2.0"or e.id==nil then
return t(nil,nil,-32600,"Invalid request")
elseif e.method=="call"then
if type(e.params)~="table"or#e.params<3 then
return t(nil,nil,-32600,"Invalid parameters")
end
local a,n,i,o=
e.params[1],e.params[2],e.params[3],e.params[4]or{}
if type(o)~="table"or o.ubus_rpc_session~=nil then
return t(e.id,nil,-32602,"Invalid parameters")
end
if a=="00000000000000000000000000000000"and luci.dispatcher.context.authsession then
a=luci.dispatcher.context.authsession
end
if not r(a,n,i)then
return t(e.id,nil,-32002,"Access denied")
end
o.ubus_rpc_session=a
local o,a=luci.util.ubus(n,i,o)
return t(e.id,o,a or 0)
elseif e.method=="list"then
if e.params==nil or(type(e.params)=="table"and#e.params==0)then
local a=luci.util.ubus()
return t(e.id,nil,a)
elseif type(e.params)=="table"then
local a,o=nil,{}
for a=1,#e.params do
if type(e.params[a])~="string"then
return t(e.id,nil,-32602,"Invalid parameters")
end
local t=luci.util.ubus(e.params[a])
if t and type(t)=="table"then
o[e.params[a]]={}
local i,i
for i,t in pairs(t)do
if type(t)=="table"then
o[e.params[a]][i]={}
local n,n
for t,n in pairs(t)do
o[e.params[a]][i][t]=h[n]or"unknown"
end
end
end
end
end
return t(e.id,nil,o)
else
return t(e.id,nil,-32602,"Invalid parameters")
end
end
return t(e.id,nil,-32601,"Method not found")
end
function action_ubus()
local e=require"luci.jsonc".new()
luci.http.context.request:setfilehandler(function(a,t)
if not t then
return nil
end
local t,e=e:parse(t)
return(not e or nil)
end)
luci.http.context.request:content()
local e=e:get()
if e==nil or type(e)~="table"then
luci.http.prepare_content("application/json")
luci.http.write_json(t(nil,nil,-32700,"Parse error"))
return
end
local t
if#e==0 then
t=s(e)
else
t={}
local a,a
for a,e in ipairs(e)do
t[a]=s(e)
end
end
luci.http.prepare_content("application/json")
luci.http.write_json(t)
end
function action_menu()
local t=require"luci.dispatcher"
local a=require"luci.util"
local e=require"luci.http"
local a=a.ubus("session","access",{ubus_rpc_session=e.getcookie("sysauth")})
local t=t.menu_json(a or{})or{}
e.prepare_content("application/json")
e.write_json(t)
end
