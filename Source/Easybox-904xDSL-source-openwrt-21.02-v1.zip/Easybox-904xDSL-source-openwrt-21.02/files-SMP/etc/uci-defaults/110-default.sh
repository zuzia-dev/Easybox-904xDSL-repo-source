/etc/init.d/avahi-daemon disable
/etc/init.d/privoxy disable
/etc/init.d/dnscrypt-proxy disable
/etc/init.d/minidlna disable
/etc/init.d/miniupnpd disable
/etc/init.d/mwan3 disable
/etc/init.d/sqm disable
/etc/init.d/samba disable
#/etc/init.d/nlbwmon disable
/etc/init.d/watchcat disable
/etc/init.d/banip disable
/etc/init.d/qos disable
/etc/init.d/samba4 disable
/etc/init.d/tinyproxy disable
/etc/init.d/collectd disable
/etc/init.d/openvpn disable
/etc/init.d/luci_statistics disable
/etc/init.d/smstools3 disable
/etc/init.d/p910nd disable
/etc/init.d/chilli disable
/etc/init.d/transmission disable
/etc/init.d/snmpd disable
/etc/init.d/3ginfo disable
/etc/init.d/vsftpd disable
/etc/init.d/tor disable
/etc/init.d/radiusd disable
/etc/init.d/adb-enablemodem disable
/etc/init.d/nft-qos disable
/etc/init.d/travelmate disable
/etc/init.d/msmtp disable
/etc/init.d/php7 disable
/etc/init.d/gammu disable
/etc/init.d/cshark disable
/etc/init.d/noddos disable
/etc/init.d/etherwake disable
/etc/init.d/wireguard disable
/etc/init.d/netserver disable
/etc/init.d/privoxy disable
/etc/init.d/rpcbind enable
/etc/init.d/rpcd enable
/etc/init.d/nfsd enable
/etc/init.d/ddns disable
/etc/init.d/ipsec disable
/etc/init.d/modemmanager disable
/etc/init.d/vpn-policy-routing disable
/etc/init.d/mdadm disable
/etc/init.d/n2n disable
/etc/init.d/relayd disable
/etc/init.d/igmpproxy disable
#mkdir /tmp/nfs
#mkdir /calls
#mkdir -p /var/spool/sms/outgoing
#mkdir -p /var/spool/sms/checked
#mkdir -p /var/spool/sms/failed
#mkdir -p /var/spool/sms/incoming
#mkdir -p /var/spool/sms/report
#mkdir -p /var/spool/sms/sent

#echo "*/10 * * * * /etc/red-led-off" >> /etc/crontabs/root

mkdir -p /mnt/sda1
#mkdir -p /billing
#ln -s /usr/bin/msmtp /usr/sbin/sendmail

#uci set uhttpd.main.listen_http='192.168.1.1:80'
#uci set uhttpd.main.listen_https='192.168.1.1:443'
#uci commit uhttpd

uci set system.@system[0].log_size='512'
uci set system.@system[0].zonename='Europe/Warsaw'
uci set system.@system[0].timezone='CET-1CEST,M3.5.0,M10.5.0/3'
uci commit system

rm /etc/ssl/certs/9168f543.0
rm /etc/ssl/certs/TÜRKTRUST_Elektronik_Sertifika_Hizmet_Sağlayıcısı_H5.crt
rm /etc/ssl/certs/7992b8bb.0
rm /etc/ssl/certs/451b5485.0
rm /etc/ssl/certs/a760e1bd.0
rm /etc/ssl/certs/Certplus_Root_CA_G1.crt
rm /etc/ssl/certs/Visa_eCommerce_Root.crt
rm /etc/ssl/certs/2c11d503.0
rm /etc/ssl/certs/Certplus_Root_CA_G2.crt
rm /etc/ssl/certs/OpenTrust_Root_CA_G1.crt
rm /etc/ssl/certs/OpenTrust_Root_CA_G2.crt
rm /etc/ssl/certs/608a55ad.0
rm /etc/ssl/certs/87229d21.0
rm /etc/ssl/certs/OpenTrust_Root_CA_G3.crt

chmod +x /etc/rc.local

#uci set network.utms.auto='0'
#uci set network.PPTP=interface
#uci set network.PPTP.proto='pptp'
#uci set network.PPTP.server='pl02.vpnonline.eu'
#uci set network.PPTP.username='twoj login'
#uci set network.PPTP.password='twoje haslo'
#uci set network.PPTP.keepalive='0'
#uci set network.PPTP.auto='0'
#uci set network.TUN=interface
#uci set network.TUN.ifname='tun0'
#uci set network.TUN.proto='none'
#uci set network.TUN.auto='1'
#uci set network.TUN.delegate='0'
#uci commit network

#uci set firewall.@zone[1].network='hilink upcwifree wan wwan PPTP TUN NCM'
#uci commit firewall

#uci set wireless.radio0=wifi-device
#uci set wireless.radio0.type='mac80211'
#uci set wireless.radio0.channel='auto'
#uci set wireless.radio0.hwmode='11g'
#uci set wireless.radio0.country='PL'
#uci set wireless.radio0.path='platform/1f400000.fpi/1e101000.usb/usb1/1-1/1-1:1.0'
#uci set wireless.radio0.disabled='1'
#uci set wireless.wifinet0=wifi-iface
#uci set wireless.wifinet0.device='radio0'
#uci set wireless.wifinet0.mode='sta'
#uci set wireless.wifinet0.network='upcwifree'
#uci set wireless.wifinet0.ssid='UPC Wi-Free #SprawdzUPCMobile!'
#uci set wireless.wifinet0.encryption='wpa2+ccmp'
#uci set wireless.wifinet0.eap_type='ttls'
#uci set wireless.wifinet0.phase1='peaplabel=1'
#uci set wireless.wifinet0.phase2='auth=MSCHAPV2'
#uci set wireless.wifinet0.identity='login'
#uci set wireless.wifinet0.password='haslo'
#uci set wireless.wifinet0.ca_cert='/etc/ssl/certs/LGI_Root_CA.cer'
#uci set wireless.wifinet0.domain_suffix_match='wifi-auth.upc.biz'
#uci set wireless.wifinet0.wps_pushbutton='0'
#uci set wireless.wifinet0.disabled='1'
#uci commit wireless

#openvpn.vpnonlinepl=openvpn
#openvpn.vpnonlinepl.config='/etc/openvpn/vpnonlinepl.ovpn'
#uci commit openvpn

#echo "0 * * * * rm /tmp/luci-indexcache && /etc/init.d/uhttpd restart" >> /etc/crontabs/root

uci set luci.ccache.enable=0
uci commit luci

#/etc/init.d/asterisk enable
#/etc/init.d/adblock enable
#/etc/init.d/dsl_control disable
#/etc/init.d/br2684ctl disable

uci del uhttpd.main.listen_https
uci set uhttpd.main.script_timeout='120'
#uci set uhttpd.main.listen_http='192.168.1.1:80'
#uci set uhttpd.main.listen_https='192.168.1.1:443'
uci set uhttpd.main.redirect_https='0'
uci set uhttpd.main.http_keepalive='0'
uci set uhttpd.main.max_requests='1'
uci set uhttpd.main.network_timeout='40'
uci commit uhttpd

#uci set luci.sauth.sessiontime='180'
uci set luci.sauth.sessiontime='360'
uci set luci.apply.rollback='60'
#uci set luci.index_display.ddns='hide'
#uci set luci.index_display.mwan='hide'
#uci set luci.index_display.60_wifi='hide'
uci commit luci

chmod 4755 /usr/bin
chmod 4755 /usr/sbin

sed -i 's|Lede|EasyBOX|g' /lib/wifi/ralink.sh

#mkdir /etc/collectd
#mkdir /etc/collectd/conf.d

cat << EOF >> /etc/profile
PS1='\e[1;31m\u@\h: \e[31m\W\e[0m\$ '
EOF

chmod -R 777 /mnt/sda1

#uci add_list dhcp.@dnsmasq[0].rebind_domain=free.aero2.net.pl
#uci commit

#mv /etc/rc.button/wps /etc/rc.button/wps.bak
#ln -s /etc/rc.button/rfkill /etc/rc.button/wps

#rm /etc/hotplug.d/net/20-smp-tune
#uci set network.globals.packet_steering=1
#uci commit network

#echo 1 >   /sys/class/net/br-lan/queues/rx-0/rps_cpus
#echo 1 >   /sys/class/net/eth0.1/queues/rx-0/rps_cpus
#echo 1 >   /sys/class/net/eth0.2/queues/rx-0/rps_cpus
#echo 1 >   /sys/class/net/eth0.3/queues/rx-0/rps_cpus
#echo 1 >   /sys/class/net/eth0.66/queues/rx-0/rps_cpus
#echo 1 >   /sys/class/net/eth0/queues/rx-0/rps_cpus
#echo 1 >   /sys/class/net/lo/queues/rx-0/rps_cpus

#echo 1 >   /sys/class/net/br-lan/queues/tx-0/xps_cpus
#echo 1 >   /sys/class/net/eth0.1/queues/tx-0/xps_cpus
#echo 1 >   /sys/class/net/eth0.2/queues/tx-0/xps_cpus
#echo 1 >   /sys/class/net/eth0.3/queues/tx-0/xps_cpus
#echo 1 >   /sys/class/net/eth0.66/queues/tx-0/xps_cpus
#echo 1 >   /sys/class/net/eth0/queues/tx-0/xps_cpus
#echo 1 >   /sys/class/net/lo/queues/tx-0/xps_cpus

#ln -s /usr/bin/kdig /usr/bin/dig
#ln -s /usr/bin/khost /usr/bin/host

uci set system.ntp.enabled=1
uci commit system

chmod +x /usr/share/3ginfo/cgi-bin/3ginfo.sh

ln -s /etc/init.d/wpad /etc/init.d/hostapd
#/etc/init.d/wpad disable
#/etc/init.d/hostapd enable

#uci set wireless.wl000=wifi-device
#uci set wireless.wl000.type='ralink'
#uci set wireless.wl000.channel='36'
#uci set wireless.wl000.legacy_rates='0'
#uci set wireless.wl000.htmode='VHT40'
#uci set wireless.wl000.disabled='1'
#uci set wireless.default_wl000=wifi-iface
#uci set wireless.default_wl000.device='wl000'
#uci set wireless.default_wl000.mode='ap'
#uci set wireless.default_wl000.ssid='EasyBOX'
#uci set wireless.default_wl000.encryption='psk2+aes'
#uci set wireless.default_wl000.key='WiFipassword'
#uci set wireless.default_wl000.network='lan'
#uci set wireless.default_wl000.disabled='1'
#uci set wireless.wl010=wifi-device
#uci set wireless.wl010.type='ralink'
#uci set wireless.wl010.channel='11'
#uci set wireless.wl010.legacy_rates='0'
#uci set wireless.wl010.htmode='VHT40'
#uci set wireless.wl010.disabled='1'
#uci set wireless.default_wl010=wifi-iface
#uci set wireless.default_wl010.device='wl010'
#uci set wireless.default_wl010.mode='ap'
#uci set wireless.default_wl010.ssid='EasyBOX1'
#uci set wireless.default_wl010.encryption='psk2+aes'
#uci set wireless.default_wl010.key='WiFipassword'
#uci set wireless.default_wl010.network='lan'
#uci set wireless.default_wl010.disabled='1'
#uci commit wireless

#chmod +x /etc/init.d/rpcbind
#/etc/init.d/rpcbind enable
#/etc/init.d/rpcd enable

#chmod +x /etc/init.d/dsl_control
chmod +x /etc/init.d/smsled
chmod +x /sbin/smsled-init.sh
chmod 0400 /lib/firmware/voice_ar9_firmware.bin
chmod 0400 /lib/firmware/ifx_firmware.bin

chmod -R u=rwX,go= /etc/dropbear


#uci set dhcp.@dnsmasq[0].cachesize='0'
#uci set dhcp.@dnsmasq[0].dnssec='0'
uci set dhcp.@dnsmasq[0].dnsforwardmax='50'
uci commit dhcp

ln -s /usr/lib/libiwinfo.so.20210430 /usr/lib/libiwinfo.so

rm /lib/firmware/isl3887usb

ln -s  /lib/functions/lantiq.sh /lib/functions/lantiq_dsl.sh

cat << EOF >> /etc/config/network

config atm-bridge 'atm'
	option encaps 'llc'
	option payload 'bridged'
	option nameprefix 'dsl'
	option vci '35'
	option vpi '8'

config dsl 'dsl'
	option annex 'b'
	option xfer_mode 'ptm'
	option line_mode 'vdsl'
	option ds_snr_offset '0'

config interface 'hilink'
	option proto 'dhcp'
	option ipv6 '0'
	option metric '10'
	option delegate '0'
	option auto '1'
	option device 'eth1'

config interface 'wwan'
	option proto 'dhcp'
	option ipv6 '0'
	option auto '1'
	option metric '10'
	option device 'usb0'

config interface 'umts'
	option proto '3g'
	option device '/dev/ttyUSB0'
	option service 'umts'
	option apn 'internet'
	option dialnumber '*99***1#'
	option ipv6 '0'
	option auto '0'
	option metric '10'

config interface 'PPTP'
	option proto 'pptp'
	option keepalive '0'
	option ipv6 '0'
	option auto '0'
	option server 'pl02.vpnonline.eu'
	option username 'twoj login'
	option password 'twoje haslo'
	option metric '10'

config interface 'TUN'
	option proto 'none'
	option delegate '0'
	option auto '1'
	option metric '10'
	option device 'tun0'

config interface 'NCM'
	option proto 'ncm'
	option delegate '0'
	option device '/dev/ttyUSB0'
	option service 'preferlte'
	option pdptype 'IP'
	option apn 'internet'
	option ipv6 '0'
	option auto '0'
	option metric '10'
EOF

uci commit network

uci set network.globals.packet_steering='1'
uci set network.inic_dev.macaddr='00:11:22:33:44:33'
uci set network.inic_dev=device
uci set network.inic_dev.name='eth0.3'
uci set network.inic=interface
uci set network.inic.proto='none'
uci set network.inic.device='eth0.3'
uci set network.wan=interface
uci set network.wan.proto='pppoe'
uci set network.wan.ipv6='1'
uci set network.wan.metric='20'
uci set network.wan.username='user@dialnet.pl'
uci set network.wan.password='passwd'
uci set network.wan.keepalive='0'
uci set network.wan.ifname='dsl0.35'
uci set network.wan.auto='1'
uci set network.wan_dev=device
uci set network.wan_dev.name='dsl0'
uci del network.lan.ifname=''eth0.66' 'eth0.66''
uci set network.@device[0].ports=''eth0.71' 'eth0.66' 'eth0.1''
uci set network.@device[0].ipv6='1'
uci set network.lan.ifname=''eth0.66' 'eth0.71' 'eth0.1''
uci set network.loopback.ipv6='1'
uci set network.@device[0].ipv6='1'
uci set network.@device[1].ipv6='1'
uci set network.lan.ipv6='1'
uci set network.wan.ipv6='1'
uci set network.inic_dev.ipv6='1'
uci set network.inic.ipv6='1'
uci set network.hilink=interface
uci set network.hilink.ipv6='0'
uci set network.hilink.device='eth1'
uci set network.hilink.proto='static'
uci set network.hilink.ipaddr='192.168.8.100'
uci set network.hilink.netmask='255.255.255.0'
uci set network.hilink.gateway='192.168.8.1'
uci set network.hilink.broadcast='192.168.8.255'
uci set network.hilink.auto='0'
uci set network.hilink.metric='10'
uci set network.hilink.dns='192.168.8.1'
uci commit network

uci set network.inic_dev.macaddr='00:11:22:33:44:33'
uci set network.inic.macaddr='00:11:22:33:44:33'
uci set network.wlan_dev.macaddr='00:11:22:33:44:66'
uci set network.guest_wlan_dev.macaddr='00:11:22:33:44:71'
uci commit network

#cat << EOF >> /etc/config/firewall

#config zone
#	option name 'hilink'
#	list network 'hilink'
#	option input 'REJECT'
#	option output 'ACCEPT'
#	option forward 'REJECT'
#	option masq '1'

#config forwarding
#	option src 'lan'
#	option dest 'hilink'
#EOF
#uci commit firewall

uci set firewall.@defaults[0]=defaults
uci set firewall.@defaults[0].syn_flood='0'
uci set firewall.@defaults[0].tcp_syncookies='0'
uci set firewall.@defaults[0].tcp_window_scaling='1'
uci set firewall.@defaults[0].accept_redirects='0'
uci set firewall.@defaults[0].accept_source_route='0'
uci set firewall.@defaults[0].input='ACCEPT'
uci set firewall.@defaults[0].output='ACCEPT'
uci set firewall.@defaults[0].forward='REJECT'
uci set firewall.@defaults[0].flow_offloading='1'
uci set firewall.@defaults[0].disable_ipv6='0'
uci set firewall.@zone[0]=zone
uci set firewall.@zone[0].name='lan'
uci set firewall.@zone[0].network='lan'
uci set firewall.@zone[0].input='ACCEPT'
uci set firewall.@zone[0].output='ACCEPT'
uci set firewall.@zone[0].forward='ACCEPT'
uci set firewall.@zone[1]=zone
uci set firewall.@zone[1].name='wan'
uci set firewall.@zone[1].network=''wan' 'wan6' 'wwan' 'PPTP' 'TUN' 'NCM' 'umts' 'hilink''
uci set firewall.@zone[1].input='REJECT'
uci set firewall.@zone[1].output='ACCEPT'
uci set firewall.@zone[1].forward='REJECT'
uci set firewall.@zone[1].masq='1'
uci set firewall.@zone[1].mtu_fix='1'
uci set firewall.@zone[1].conntrack='1'
uci set firewall.@zone[1].log='0'
uci set firewall.@zone[1].log_limit='60/minute'
uci commit firewall

uci set wireless.wl000.disabled='0'
uci set wireless.wl010.disabled='0'
uci set wireless.default_wl000.ssid='EasyBOX-5GHz'
uci set wireless.default_wl010.ssid='EasyBOX-2GHz'
uci set wireless.wl000.legacy_rates='0'
uci set wireless.wl000.htmode='VHT40'
uci set wireless.wl010.legacy_rates='0'
uci set wireless.wl010.htmode='VHT40'
uci del wireless.default_wl000.network='lan'
uci commit wireless


uci set adblock.global=adblock
uci set adblock.global.adb_nullipv4='192.168.1.1'
uci set adblock.global.adb_trigger='wan'
uci set adblock.global.adb_debug='0'
uci set adblock.global.adb_safesearch='0'
uci set adblock.global.adb_dnsfilereset='0'
uci set adblock.global.adb_mail='0'
uci set adblock.global.adb_report='0'
uci set adblock.global.adb_backup='1'
uci set adblock.global.adb_nice='10'
uci set adblock.global.adb_forcesrt='0'
uci set adblock.global.adb_forcedns='1'
uci set adblock.global.adb_dnsflush='1'
uci set adblock.global.adb_maxqueue='8'
uci set adblock.global.adb_triggerdelay='60'
uci set adblock.global.adb_dns='dnsmasq'
uci set adblock.global.adb_fetchutil='wget'
uci set adblock.global.adb_sources=''adaway' 'android_tracking' 'disconnect' 'reg_pl1' 'reg_pl2' 'wally3k' 'winhelp' 'winspy' 'yoyo''
uci set adblock.global.adb_enabled='1'
uci commit adblock

touch /var/etc/timecontrol.include

chmod +x /usr/bin/watchdog2cron.sh
chmod +x /usr/bin/lite-watchdog-data.sh
chmod +x /usr/bin/lite_watchdog.sh
chmod +x /sbin/cronsync.sh
chmod +x /sbin/set_sms_ports.sh
chmod +x /sbin/smsled-init.sh
chmod +x /sbin/smsled.sh








